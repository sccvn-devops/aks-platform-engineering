# PRD: IDP GitOps Blueprint v3 — Terraform Hardening Addendum

**Version:** 3.0
**Date:** 2026-05-22
**Author:** Platform Engineering

---

## Purpose

This PRD is an **addendum** to `IDP-GitOps-Blueprint-PRD.md` (v2) and the locked
ADR set in `IDP-GitOps-ADRs-v2.md`. It extends — and does not modify — the v2
scope by bolting on **Terraform code-quality, supply-chain, and state-management
hardening** capabilities that close a set of P0/P1/P2 findings raised during the
post-v2 readiness review. All v2 functional requirements (FR-1..FR-25), user
stories (US-001..US-025), non-goals, and architectural decisions remain in force
verbatim. PRD-v3 adds new requirements under a separate `FR-V3-NN` /
`US-V3-NN` / `OQ-V3-NN` namespace so the v2 numbering is preserved.

---

## Scope

### In Scope (v3 additions only)

| Area | Addition |
|---|---|
| State backend | Remote AzureRM backend with per-env state files; native blob lease locking; out-of-band bootstrap of the state SA |
| Secret material in repo | Purge of historical TLS material; AKV-issued certs synced via ESO; OIDC-federated AKV fetch for sensitive `TF_VAR_*` in CI |
| RBAC for managed identities | RG-scoped role assignments for `akspe` and Velero UAMIs (replace subscription-Owner defaults) |
| Pre-commit + PR gates | `pre-commit` framework with a minimal hook set; GitHub Actions meta-CI for the platform repo |
| Variable validation | Critical-path inline `validation {}` plus `tflint-ruleset-azurerm` and a custom tflint rule detecting unvalidated variables |
| Supply-chain scanning | `checkov` with `.checkov.baseline`, advisory then blocking; CODEOWNERS-protected suppressions |
| Static analysis | SonarQube/SonarCloud for Backstage TypeScript and Dockerfiles; hosting selected by `var.sonar_hosting` (`"saas"` default, `"cipool"` self-hosted optional — see FR-V3-25 and ADR-016-v3-amendment) |
| Terraform version | Pin `~> 1.5.0` (LTS-ish stability; 1.5.x is the last MPL-licensed line and is broadly supported by the tooling matrix) |
| Determinism | Replace `uuid()` interpolations with `random_uuid` resources keyed by stable inputs |

### Out of Scope (v3)

| Area | Reason |
|---|---|
| Terragrunt adoption | Anti-rabbit-hole; not reopened |
| Replacement of Terraform with Pulumi or Bicep | Anti-rabbit-hole; not reopened |
| Migration of application CI from Jenkins to GitHub Actions | Locked by ADR-001-v2 |
| Replacement of Kyverno with OPA/Gatekeeper | Locked by ADR-008-v2 |
| Self-hosting Sonar on `mgmt-we` | Forbidden by ADR-016; only `cipool` or SaaS allowed |
| Customer-managed-key (CMK) encryption for the state SA | Roadmap; v3 ships with Microsoft-managed keys (MSE) |
| Any change to v2 FRs, ADRs, or user stories | v3 is additive only |

---

## Background

A readiness review of the v2 Terraform code base produced **nine findings**
across three severity tiers:

| Severity | Count | Findings |
|---|---|---|
| **P0** (security / data-loss) | 4 | F-01 no remote backend; F-05 plaintext credential defaults persisted into state; F-06 `tls.key` checked into git; F-07 `akspe` UAMI granted subscription-scoped Owner |
| **P1** (quality gates) | 3 | F-02 no pre-commit/PR lint; F-03 no variable validation; F-04 no `checkov` scanning |
| **P2** (polish) | 2 | F-08 Terraform version floor too permissive; F-09 `uuid()` causes drift |

The v2 PRD assumed these were already mitigated by industry-standard hygiene;
the review proved otherwise. Without v3 closing them, the platform's state
file, sensitive material, and identity blast-radius represent unacceptable risk
for production use. The locked decisions from the design-grilling session
provide the implementation contract this PRD codifies.

---

## Functional Requirements

### State Backend (closes F-01)

- **FR-V3-01** — Terraform state for every environment must be stored in a
  remote AzureRM backend. The state storage account must be provisioned
  **out-of-band** by `/scripts/bootstrap-tfstate.sh` (an idempotent Azure CLI
  script) into a dedicated resource group `rg-tfstate-bootstrap` carrying a
  management lock of type `CanNotDelete`.
- **FR-V3-02** — State files must be partitioned per environment using the key
  pattern `tfstate/<env>/<cluster>.tfstate`, with the following keys mandatory
  on day-1: `mgmt-we`, `mgmt-ne`, `dev`, `staging`, `prod-we`, `prod-ne`,
  `seed-wus`. No single state file may span more than one cluster.
- **FR-V3-03** — State locking must use the native Azure Blob lease mechanism
  built into the `azurerm` provider backend. No external lock store (DynamoDB,
  Cosmos, custom table) is permitted.
- **FR-V3-04** — Server-side encryption for the state SA must use
  Microsoft-managed keys (MSE) for v3. Customer-managed keys (CMK) backed by
  AKV are tracked as roadmap (see OQ-V3-04) and **must not** be retrofitted
  inside v3 without a follow-up ADR.

### Secret Material and RBAC (closes F-05, F-06, F-07)

- **FR-V3-05** — Any historical TLS material (`*.key`, `*.crt`) committed to
  the repository must be purged from git history using `git filter-repo`,
  followed by a force-push to the canonical remote. The compromised
  certificate must be **rotated**, the old certificate **revoked** at the
  issuing CA, and `*.key` / `*.crt` added to `.gitignore`.
- **FR-V3-06** — All future certificates required by the platform must be
  issued by Azure Key Vault and synced into Kubernetes by External Secrets
  Operator. This aligns with ADR-005-v2 (per-namespace SecretStore) and
  ADR-020 (AKV as cert authority of record).
- **FR-V3-07** — A `detect-private-key` pre-commit hook must block any commit
  containing PEM-encoded key material from re-introducing the same class of
  defect.
- **FR-V3-08** — All sensitive Terraform inputs (subscription IDs, client
  secrets, SAS tokens, SaaS API tokens, connection strings) must be sourced
  via `data "azurerm_key_vault_secret"` blocks. No sensitive variable may
  carry a `default = "..."` value. No plaintext `*.tfvars` file containing
  sensitive material may be committed.
- **FR-V3-09** — CI workflows must fetch sensitive values from AKV using
  the **already-provisioned** OIDC federated credential that maps the
  GitHub Actions OIDC issuer (`token.actions.githubusercontent.com`,
  audience `api://AzureADTokenExchange`, subject pinned per repo +
  protected `main` environment) to the `gha-platform-ci` user-assigned
  managed identity. v3 must **reference and consume** this existing
  federated credential — not re-provision it. The MI's role
  assignments must be limited to the AKV secrets it needs to read at
  TF-time (`Key Vault Secrets User` scoped to each per-env vault) and
  must not include any subscription- or RG-level write roles. The
  workflow exports the fetched secrets as `TF_VAR_*` environment
  variables for the duration of the job (masked in logs). Static
  service-principal credentials, client secrets, or long-lived
  certificates for CI are prohibited.
- **FR-V3-10** — The `akspe` user-assigned managed identity must hold
  **Contributor** plus **User Access Administrator** roles scoped to the AKS
  resource groups only — never at the subscription scope. The subscription-Owner
  default introduced in early development must be removed.
- **FR-V3-11** — The Velero managed identity must hold **Contributor** on its
  backup resource group and **Storage Blob Data Contributor** on the backup
  storage account only.
- **FR-V3-12** — Rotation of AKV-stored keys and certificates must rely on
  AKV-native quarterly rotation policies. UAMI and SP credentials must be
  federated via Workload Identity so that there are no static credentials in
  need of rotation.

### Pre-commit and PR Gates (closes F-02)

- **FR-V3-13** — The repository must adopt the `pre-commit` framework
  (Python-based) as the canonical local hook runner. A `.pre-commit-config.yaml`
  at the repo root must be the single source of truth for hook configuration.
- **FR-V3-14** — The v3 minimal hook set must include exactly:
  `terraform_fmt`, `terraform_validate`, `tflint`, `detect-private-key`,
  `end-of-file-fixer`, and `trailing-whitespace`. Additional hooks may be
  proposed via ADR but are not required at v3 GA.
- **FR-V3-15** — Platform-repo meta-CI must run on GitHub Actions for both
  Terraform and Backstage workflows. App CI continues to run on Jenkins
  hosted on `cipool` per ADR-001-v2; v3 introduces no change to app CI.
- **FR-V3-16** — Gate blocking must be phased: `terraform_fmt`,
  `terraform_validate`, and `tflint` are **blocking from day-1**. `checkov`
  is **advisory in sprint-1** and **blocking from sprint-2** once a baseline
  has landed. SonarQube remains advisory for HCL content (covered by tflint
  and checkov instead).
- **FR-V3-17** — The GitHub Actions workflow must be implemented as a
  **matrix** of one job per env-state. `terraform plan` must run on every
  PR against `main`. `terraform apply` must be gated behind a
  **GitHub Environment with required reviewers** (one Environment per
  env-state: `dev`, `staging`, `prod-we`, `prod-ne`, `mgmt-we`,
  `mgmt-ne`, `seed-wus`). Each Environment must list at least two
  members of `@<org>/platform-team` as required reviewers, must scope
  the OIDC subject claim to that Environment, and must restrict deploy
  branches to `main` only. `terraform apply` on a PR branch is
  rejected by Environment branch protection.

### Variable Validation (closes F-03)

- **FR-V3-18** — Critical-path Terraform variables must carry inline
  `validation {}` blocks from day-1. The day-1 critical-path set is: region,
  cluster name, SKU tier, CIDR block, and environment (with regex
  `^(dev|staging|prod)$`). Coverage must ratchet to 100% of variables across
  two subsequent sprints.
- **FR-V3-19** — Cloud-resource-level rules (naming, SKU constraints,
  required tags) must be enforced through `tflint-ruleset-azurerm` rather than
  duplicated inside `validation {}` blocks.
- **FR-V3-20** — A custom tflint rule must flag any new variable declaration
  that lacks a `validation {}` block and is not yet covered by the
  100%-coverage ratchet. This rule is advisory while the ratchet is in
  progress and blocking once 100% is declared.

### Supply Chain (closes F-04)

- **FR-V3-21** — `checkov` must run against all Terraform code with the
  configuration file `.checkov.yaml` at the repo root. A `.checkov.baseline`
  file at the repo root tracks accepted findings. Until a dedicated
  Platform Security guild team exists, ownership of `.checkov.baseline`
  is assigned in `CODEOWNERS` to **`@<org>/platform-team`** (interim
  owner). Once a Security guild team is stood up, the CODEOWNERS entry
  must be re-pointed to it via a follow-up PR; this hand-off is tracked
  as a v3+1 backlog item, not a v3 GA blocker.
- **FR-V3-22** — Suppressions inside Terraform code must be inline of the form
  `# checkov:skip=CKV_*:<jira-ticket>` and must include an expiry date in the
  referenced Jira ticket. Suppressions without a ticket or with an expired
  ticket cause the build to fail.
- **FR-V3-23** — `checkov` must execute in **both** the pre-commit hook and
  the CI pipeline, using the **same** `.checkov.yaml`. Local and CI results
  must be identical for the same commit.

### Static Analysis (Backstage + Dockerfiles)

- **FR-V3-24** — SonarQube (SaaS SonarCloud by default, see FR-V3-25)
  must scan the Backstage TypeScript source and the Dockerfiles only.
  HCL is out-of-scope for Sonar; it is covered by `tflint` and
  `checkov` per the decisions matrix. **Sonar onboarding for the
  Backstage app is greenfield** — no prior Sonar project, profile, or
  history exists for `backstage/`. The Platform team owns the
  onboarding deliverables: (a) a `sonar-project.properties` file at
  `backstage/sonar-project.properties` configuring project key,
  organization, source paths (`packages/`), and exclusions
  (`**/*.test.ts`, `**/dist/**`, `**/node_modules/**`); (b) a
  GitHub Actions step in the Backstage workflow that runs
  `sonar-scanner` against `var.sonar_hosting`'s selected endpoint and
  uploads the analysis with coverage from `yarn test:all`; (c) the
  initial Sonar **quality gate** configured per FR-V3-26 (Sonar Way
  with the 80% new-code coverage override). No migration of existing
  findings is required because there are none.
- **FR-V3-25** — Sonar **hosting is configurable** via the Terraform
  variable `var.sonar_hosting`, declared as
  `type = string`, `default = "saas"`, with an inline `validation {}`
  block restricting values to the enum `"saas" | "cipool"`. `"saas"`
  selects SonarCloud (the default for v3 GA). `"cipool"` provisions a
  self-hosted Sonar Helm release onto the `cipool` node pool of
  `mgmt-we` (see FR-V3-25a and ADR-016-v3-amendment — `cipool` is the
  only allowed in-cluster host for Sonar; `systempool` on `mgmt-we`
  and `mgmt-ne` remain prohibited). The variable is consumed by the
  GHA meta-CI workflow to select the SonarCloud vs. in-cluster
  endpoint, and by the Terraform module that conditionally creates
  the in-cluster Helm release.
- **FR-V3-25a** — When `var.sonar_hosting = "cipool"`, the
  self-hosted Sonar deployment must land exclusively on the `cipool`
  node pool (`nodeSelector: { nodepool: cipool }`,
  `tolerations: [{ key: workload, value: ci, effect: NoSchedule }]`)
  and must not schedule onto `systempool` of `mgmt-we` or onto
  `mgmt-ne`. This placement is permitted by the ADR-016 amendment
  (see OQ-V3-05) which scopes the "platform-only" rule to
  management `systempool`s and explicitly allows DX-plane tooling
  (Jenkins, Sonar) on `cipool`.
- **FR-V3-26** — The Sonar quality profile is **Sonar Way** with one
  override: **new-code coverage must be greater than or equal to 80%**.
  This gate is advisory for one sprint, then blocking on the
  `packages/backend` workspace.

### Terraform Version and Determinism (closes F-08, F-09)

- **FR-V3-27** — The required Terraform version must be pinned to
  `~> 1.5.0` across every module. This selects the LTS-ish 1.5.x line
  (the last MPL-licensed release series, with mature provider and
  tooling support across `tflint`, `checkov`, and the `azurerm`
  provider) and allows patch upgrades within 1.5.x while blocking
  unscheduled minor jumps that have not been validated against the
  ruleset.
- **FR-V3-28** — Every occurrence of `uuid()` inside Terraform code must be
  replaced with a `random_uuid` resource configured with a `keepers` map of
  the form `{ trigger = var.cluster_name }`. This eliminates per-plan drift
  while preserving regeneration when the keyed input changes.

---

## User Stories

### US-V3-01: Remote State Backend with Out-of-Band Bootstrap
**Description:** As a platform engineer, I want Terraform state stored in a
remote AzureRM backend bootstrapped out-of-band so that I never risk state loss
from a developer laptop and the chicken-and-egg of "Terraform managing its own
state SA" never arises.
**Acceptance Criteria:**
- **Given** a fresh subscription with no Terraform footprint,
- **When** I run `/scripts/bootstrap-tfstate.sh` once,
- **Then** the resource group `rg-tfstate-bootstrap` exists with a
  `CanNotDelete` management lock, the storage account is provisioned, blob
  versioning is enabled, and re-running the script is idempotent.
- **Given** the bootstrap is complete,
- **When** I run `terraform init` in any environment,
- **Then** the backend resolves successfully against the partitioned key
  `tfstate/<env>/<cluster>.tfstate`.

### US-V3-02: Per-Environment State Partitioning
**Description:** As a platform engineer, I want one state file per cluster so
that blast radius from a corrupted lock or a botched apply is bounded to a
single environment.
**Acceptance Criteria:**
- **Given** the state account is bootstrapped,
- **When** I list state keys after the initial apply of all environments,
- **Then** exactly seven keys exist: `tfstate/mgmt-we/...`,
  `tfstate/mgmt-ne/...`, `tfstate/dev/...`, `tfstate/staging/...`,
  `tfstate/prod-we/...`, `tfstate/prod-ne/...`, `tfstate/seed-wus/...`.
- **Given** an apply in `dev` is in progress,
- **When** an apply is initiated in `prod-we`,
- **Then** the second apply is not blocked because the lease is scoped to the
  `dev` blob only.

### US-V3-03: Native Azure Blob Lease Locking
**Description:** As a platform engineer, I want state locking handled by the
azurerm backend's native blob lease so that there is no second locking system
to operate.
**Acceptance Criteria:**
- **Given** two concurrent `terraform apply` invocations against the same env,
- **When** both attempt to acquire the lease,
- **Then** one succeeds and the second waits or fails with a clear lease-held
  error message — no external lock service is consulted.

### US-V3-04: State Encryption with MSE
**Description:** As a platform engineer, I want server-side encryption with
Microsoft-managed keys enabled on the state SA so that data-at-rest protection
is guaranteed without taking on CMK operational cost in v3.
**Acceptance Criteria:**
- **Given** the state SA exists,
- **When** I read its encryption configuration,
- **Then** `encryption.services.blob.enabled = true` with
  `keyType = Microsoft-managed`, and no CMK references are present.

### US-V3-05: Purge TLS Material from Git History
**Description:** As a platform engineer, I want all historical `tls.key` and
`tls.crt` material removed from git history, the certificate rotated, and the
old certificate revoked at the CA so that the compromise window closes.
**Acceptance Criteria:**
- **Given** the repository at HEAD,
- **When** I clone it fresh and run `git log -p -- '**/tls.key'`,
- **Then** no historical content is returned.
- **Given** the purge is complete,
- **When** I check the issuing CA,
- **Then** the old certificate is in the revocation list and a new certificate
  is bound to the live workload.
- **Given** the purge is complete,
- **When** any developer attempts to commit a file matching `*.key` or `*.crt`,
- **Then** `.gitignore` excludes it and the `detect-private-key` hook rejects
  PEM content regardless of filename.

### US-V3-06: AKV-Issued Certs via ESO
**Description:** As a platform engineer, I want all platform certificates
issued by Azure Key Vault and synced into Kubernetes by ESO so that no
certificate material ever lives in git.
**Acceptance Criteria:**
- **Given** a workload namespace with a NamespaceVaultBinding (per US-017),
- **When** a certificate is issued in the corresponding AKV,
- **Then** ESO materializes it as a Kubernetes TLS Secret within the secret
  freshness SLO (p95 ≤ 90s, inherited from PRD-v2).

### US-V3-07: AKV-Sourced Sensitive TF Variables
**Description:** As a platform engineer, I want every sensitive Terraform
variable sourced from AKV via `data "azurerm_key_vault_secret"` so that no
sensitive value ever lands in a tfvars file or default expression.
**Acceptance Criteria:**
- **Given** the Terraform code base,
- **When** I `grep` for `default =` on variables flagged sensitive,
- **Then** zero matches are returned.
- **Given** a CI run,
- **When** the job starts,
- **Then** sensitive `TF_VAR_*` values are populated from AKV via OIDC
  federation and are masked in CI logs.

### US-V3-08: RG-Scoped `akspe` and Velero RBAC
**Description:** As a platform engineer, I want `akspe` and the Velero UAMI
scoped to specific resource groups so that compromise of either does not grant
subscription-wide control.
**Acceptance Criteria:**
- **Given** the applied Terraform,
- **When** I list role assignments for `akspe`,
- **Then** only `Contributor` and `User Access Administrator` are present, and
  every assignment is scoped to an AKS resource group — never to the
  subscription.
- **Given** the applied Terraform,
- **When** I list role assignments for the Velero UAMI,
- **Then** only `Contributor` on the backup RG and `Storage Blob Data
  Contributor` on the backup SA are present.

### US-V3-09: AKV-Native Quarterly Rotation
**Description:** As a platform engineer, I want quarterly rotation of keys and
certificates handled by AKV-native rotation policies and federation for
identities so that v3 introduces no new manual rotation toil.
**Acceptance Criteria:**
- **Given** an AKV key or certificate provisioned by v3,
- **When** I inspect its rotation policy,
- **Then** a quarterly policy is attached and the next rotation timestamp is
  visible.
- **Given** a UAMI or SP used by the platform,
- **When** I inspect its credential profile,
- **Then** it is federated via Workload Identity with no client secret on
  record.

### US-V3-10: Adopt `pre-commit` Framework
**Description:** As a platform engineer, I want `pre-commit` to be the
canonical local hook runner so that every contributor runs the same checks
locally that CI runs centrally.
**Acceptance Criteria:**
- **Given** a fresh clone,
- **When** I run `pre-commit install`,
- **Then** the hook set described in FR-V3-14 is registered and any subsequent
  commit triggers it.

### US-V3-11: Minimal v3 Hook Set
**Description:** As a platform engineer, I want a small, fast, deterministic
hook set in v3 so that local commits are not bogged down by long-running
checks while still catching the worst defects.
**Acceptance Criteria:**
- **Given** `.pre-commit-config.yaml` at HEAD,
- **When** I enumerate the hooks,
- **Then** exactly `terraform_fmt`, `terraform_validate`, `tflint`,
  `detect-private-key`, `end-of-file-fixer`, and `trailing-whitespace` are
  configured — no more, no fewer, at v3 GA.

### US-V3-12: GitHub Actions Meta-CI
**Description:** As a platform engineer, I want platform-repo CI on GitHub
Actions so that the workflow runs on infrastructure not coupled to the
`mgmt-we` cluster whose Terraform is being changed.
**Acceptance Criteria:**
- **Given** a PR against `main`,
- **When** it opens or updates,
- **Then** a GitHub Actions workflow runs `terraform fmt`, `terraform validate`,
  `tflint`, `checkov`, and `terraform plan` per env.
- **Given** the platform-repo CI exists,
- **When** I inspect Jenkins,
- **Then** application CI continues to run there per ADR-001-v2 with no
  v3-driven change.

### US-V3-13: Phased Blocking Gates
**Description:** As a platform engineer, I want gates phased so that the team
absorbs new failure modes without being swamped at cutover.
**Acceptance Criteria:**
- **Given** day-1 of v3 rollout,
- **When** a PR fails `terraform_fmt`, `terraform_validate`, or `tflint`,
- **Then** the PR is blocked from merging.
- **Given** sprint-1 of v3 rollout,
- **When** a PR fails `checkov`,
- **Then** a warning is posted but the PR is not blocked.
- **Given** sprint-2 of v3 rollout,
- **When** a PR fails `checkov` and the baseline does not cover the finding,
- **Then** the PR is blocked.

### US-V3-14: GHA Matrix with Required-Reviewer Apply Gate
**Description:** As a platform engineer, I want one CI job per env-state and
a `terraform apply` gated by a GitHub Environment with required reviewers
so that no environment is changed without an explicit, recorded human
decision.
**Acceptance Criteria:**
- **Given** a PR touching Terraform,
- **When** CI runs,
- **Then** the matrix produces one `plan` job per env-state listed in
  FR-V3-02, each posting its plan diff to the PR.
- **Given** a merge to `main`,
- **When** the apply workflow is invoked,
- **Then** each env-state apply job targets its corresponding GitHub
  Environment (e.g., `prod-we`), which pauses the run until one of the
  configured required reviewers approves; approvals and reviewer
  identities are recorded in the GitHub Actions run history.
- **Given** an attempt to invoke `terraform apply` from a PR branch,
- **When** the job starts,
- **Then** Environment branch protection rejects the deploy because the
  branch is not `main`.

### US-V3-15: Critical-Path Variable Validation
**Description:** As a platform engineer, I want validation blocks on the
critical-path variables from day-1 so that obvious misconfigurations fail at
`plan` rather than at apply.
**Acceptance Criteria:**
- **Given** the v3 Terraform at GA,
- **When** I review variables for region, cluster name, SKU tier, CIDR, and
  environment,
- **Then** each carries an inline `validation {}` block with a clear
  `error_message`.
- **Given** a value such as `env = "qa"` is passed,
- **When** `terraform plan` runs,
- **Then** the regex `^(dev|staging|prod)$` rejects it with a meaningful
  error.
- **Given** v3 + 2 sprints,
- **When** I audit variable coverage,
- **Then** 100% of variables carry a `validation {}` block or are explicitly
  exempted via a tflint allow-list with rationale.

### US-V3-16: Resource-Level Rules via tflint + Custom Detection
**Description:** As a platform engineer, I want cloud-resource rules in
`tflint-ruleset-azurerm` and a custom rule that flags unvalidated variables so
that the validation regime is observable and enforceable.
**Acceptance Criteria:**
- **Given** the tflint config at HEAD,
- **When** I list active rulesets,
- **Then** `tflint-ruleset-azurerm` is enabled with documented overrides.
- **Given** a contributor adds a new variable without `validation {}`,
- **When** tflint runs,
- **Then** the custom rule emits a warning (during the ratchet) or an error
  (post 100%-coverage cutover).

### US-V3-17: `.checkov.baseline` with CODEOWNERS Ownership
**Description:** As a platform engineer, I want the checkov baseline owned
by `@<org>/platform-team` (interim, until a dedicated Platform Security
guild exists) so that exceptions are not silently inflated by arbitrary
contributors.
**Acceptance Criteria:**
- **Given** the repository,
- **When** I open `CODEOWNERS`,
- **Then** `.checkov.baseline` is owned by `@<org>/platform-team` (with a
  TODO comment naming the Security guild as the future owner).
- **Given** a PR that mutates `.checkov.baseline`,
- **When** CI runs,
- **Then** review from a CODEOWNERS member is required before merge.
- **Given** an inline `# checkov:skip=CKV_*:<ticket>` without a referenced
  Jira ticket or with an expired ticket,
- **When** checkov runs,
- **Then** the build fails.

### US-V3-18: Checkov in Both pre-commit and CI
**Description:** As a platform engineer, I want checkov to run identically in
pre-commit and CI so that local failures are reproducible against the same
ruleset.
**Acceptance Criteria:**
- **Given** the same commit SHA,
- **When** checkov runs locally via pre-commit and in GitHub Actions,
- **Then** both consume `.checkov.yaml` and produce the same exit code and
  the same finding set.

### US-V3-19: SonarQube Scope Limited to TypeScript + Dockerfiles
**Description:** As a platform engineer, I want Sonar limited to Backstage
TypeScript and Dockerfiles so that we do not double-cover HCL or pay for
analysis that produces no incremental signal.
**Acceptance Criteria:**
- **Given** Sonar's project configuration,
- **When** I review the inclusion/exclusion patterns,
- **Then** TypeScript under `backstage/` and `Dockerfile*` are included and
  `**/*.tf` is excluded.

### US-V3-20: Configurable Sonar Hosting
**Description:** As a platform engineer, I want a documented toggle between
SonarCloud SaaS (default) and self-hosted Sonar on `cipool` so that operators
can comply with future data-residency or cost constraints without re-engineering
the gate.
**Acceptance Criteria:**
- **Given** the v3 release,
- **When** an operator sets `var.sonar_hosting = "saas"` (the default),
- **Then** the meta-CI uses SonarCloud and no in-cluster Sonar exists.
- **Given** the v3 release,
- **When** an operator sets `var.sonar_hosting = "cipool"`,
- **Then** Sonar runs on the `cipool` node pool of `mgmt-we` (never on
  `systempool` of `mgmt-we` or anywhere on `mgmt-ne`, per
  ADR-016-v3-amendment) and CI points at the in-cluster endpoint.
- **Given** the toggle variable,
- **When** any value other than `"saas"` or `"cipool"` is supplied,
- **Then** the inline `validation {}` block on `var.sonar_hosting`
  fails `terraform plan` with a clear error message.

### US-V3-21: Sonar Way + 80% New-Code Coverage Override
**Description:** As a platform engineer, I want Sonar Way as the default
profile with an 80% new-code coverage override so that code quality steadily
improves without rewriting history.
**Acceptance Criteria:**
- **Given** the configured profile,
- **When** I open the quality gate,
- **Then** Sonar Way is selected and the new-code coverage threshold is set
  to 80%.
- **Given** sprint-1 of Sonar rollout,
- **When** the gate fails for `packages/backend`,
- **Then** a warning is posted but the PR is not blocked.
- **Given** sprint-2 onward,
- **When** the gate fails for `packages/backend`,
- **Then** the PR is blocked.

### US-V3-22: Pin Terraform `~> 1.5.0`
**Description:** As a platform engineer, I want Terraform pinned to `~> 1.5.0`
so that patch upgrades are accepted automatically within the LTS-ish 1.5.x
line (the last MPL-licensed series) while minor jumps are deliberate and
validated against the full ruleset.
**Acceptance Criteria:**
- **Given** any Terraform module at HEAD,
- **When** I read `required_version`,
- **Then** it reads `~> 1.5.0`.
- **Given** CI,
- **When** the workflow boots,
- **Then** the installed Terraform version satisfies `~> 1.5.0`.

### US-V3-23: Replace `uuid()` with `random_uuid` Resources
**Description:** As a platform engineer, I want every `uuid()` interpolation
replaced with a `random_uuid` resource keyed to the cluster name so that no
plan diff surfaces without a real input change.
**Acceptance Criteria:**
- **Given** the Terraform code base,
- **When** I `grep -R 'uuid()' terraform/`,
- **Then** zero matches are returned.
- **Given** the same module,
- **When** I run `terraform plan` twice without input changes,
- **Then** the second plan is empty.
- **Given** `var.cluster_name` changes,
- **When** `terraform plan` runs,
- **Then** the `random_uuid` regenerates as expected.

---

## Non-Goals

- **Terragrunt adoption** — Not reopened. Plain Terraform with the v3
  hardening regime is the chosen path.
- **Replacement of Terraform with Pulumi or Bicep** — Not reopened. Migration
  of IaC engine is a separate, multi-quarter conversation outside v3.
- **Migration of application CI from Jenkins to GitHub Actions** — Locked by
  ADR-001-v2. GitHub Actions in v3 is **only** for platform-repo meta-CI
  (Terraform + Backstage). App CI continues on Jenkins on `cipool`.
- **OPA / Gatekeeper instead of Kyverno** — Locked by ADR-008-v2. Kyverno is
  the sole policy engine.
- **Self-hosting Sonar on `mgmt-we`** — Forbidden by ADR-016. The
  configurable hosting toggle allows SaaS or `cipool`; `mgmt-we` is excluded
  by construction.
- **CMK encryption for the state SA in v3** — Roadmap. v3 ships MSE only.
- **Modification of any v2 FR, ADR, or user story** — v3 is purely additive.

---

## Rollout and Ownership

### Phase ordering (strict)

| Phase | Findings closed | Gating exit criterion |
|---|---|---|
| **P0** | F-01, F-05, F-06, F-07 | All four P0 findings closed: remote backend live for every env; no sensitive defaults in state; tls material purged + rotated + revoked; UAMIs RG-scoped |
| **P1** | F-02, F-03, F-04 | `pre-commit` + GHA matrix live; critical-path variable validation in place; `.checkov.baseline` landed and `checkov` blocking from sprint-2 |
| **P2** | F-08, F-09 | Terraform pinned `~> 1.5.0`; `uuid()` fully replaced by `random_uuid` |

P0 must close before P1 begins. P1 must close before P2 begins. There is no
parallelization across phases; within a phase, work items may run in parallel
where the dependency graph allows.

### Ownership

The **Platform Engineering team owns all v3 work end-to-end** — design,
implementation, gating, rollout, retrospectives, and post-GA support. The
ownership scope explicitly includes:

- All Terraform infra and module changes (state backend bootstrap, RBAC
  scope-down, version pin, validation, `random_uuid` migration).
- The pre-commit + GitHub Actions meta-CI plumbing (workflows,
  Environments + required reviewers, OIDC federation consumption).
- The **Backstage SonarQube application-code onboarding** described in
  FR-V3-24 (`sonar-project.properties`, CI step, initial quality gate
  configuration). This sits inside the `backstage/` workspace which is
  also Platform-team-owned; v3 does not require coordination with any
  application team for Sonar.
- The `.checkov.yaml` / `.checkov.baseline` lifecycle and the
  CODEOWNERS entry pointing at `@<org>/platform-team` (interim, per
  FR-V3-21).
- The ADR-016-v3-amendment authoring (per OQ-V3-05).

v3 work is **not** split with application teams. Application teams will
inherit the gate behavior on the next PR they raise after each phase ships.

---

## Open Questions (deliberately unresolved)

- **OQ-V3-01** — *Resolved (2026-05-22).* Toggle is the Terraform
  variable `var.sonar_hosting` (enum `"saas" | "cipool"`, default
  `"saas"`), promoted into FR-V3-25 / FR-V3-25a. The ADR-016
  reconciliation is addressed by ADR-016-v3-amendment, tracked under
  OQ-V3-05. Closed.
- **OQ-V3-02** — *Resolved (2026-05-22).* Pin selected as `~> 1.5.0`
  (LTS-ish; last MPL-licensed series; compatible with current GitHub
  Actions runner images and the tflint / checkov toolchain). No
  fallback required. Closed.
- **OQ-V3-03** — Coordinate force-push timing for the `git filter-repo`
  purge of `tls.key` / `tls.crt`. All downstream consumers (developer
  clones, automation accounts, CI caches) must be notified and re-cloned
  in a single coordinated window. BFG remains a fallback should
  `filter-repo` encounter unsupported repo characteristics.
- **OQ-V3-04** — CMK migration path. When does the AKV-backed CMK roadmap
  item become committed? What is the data-migration plan for the state SA
  (in-place rotate vs. mirror-to-new-SA-and-cutover)?
- **OQ-V3-05** — *Dependency, not blocker.* The self-hosted Sonar path
  (`var.sonar_hosting = "cipool"`, per FR-V3-25 / FR-V3-25a) depends on
  **ADR-016-v3-amendment** being ratified. The amendment scopes the
  ADR-016 "no workloads on management clusters" rule strictly to
  management `systempool`s (`mgmt-we` and `mgmt-ne`) and explicitly
  permits DX-plane tooling — Jenkins (already on `cipool` per ADR-001-v2)
  and Sonar — on the `cipool` node pool. v3 GA may ship with the
  amendment in `Proposed` status as long as the SaaS default
  (`var.sonar_hosting = "saas"`) is the active setting; switching to
  `"cipool"` requires the amendment to be `Accepted`. Tracked in
  `_docs/IDP-GitOps-ADRs-v2.md` as `ADR-016-v3-amendment`.

---

## Dependencies on PRD-v2

PRD-v3 builds on the following v2 capabilities and ADRs. If any of these
regresses, the corresponding v3 requirement is impacted:

- **FR-7 / FR-8 / ADR-005-v2 / ADR-020** — Per-namespace ESO with
  AKV-as-truth underpins FR-V3-06 (AKV-issued certs synced by ESO) and
  FR-V3-08 (AKV-sourced sensitive TF inputs).
- **FR-13 / ADR-001-v2** — Jenkins-on-`cipool` for app CI is preserved; v3's
  GitHub Actions meta-CI explicitly does not displace it (FR-V3-15).
- **FR-21 (GitOps engine) / ADR-007** — ArgoCD remains the GitOps engine; v3
  does not alter ArgoCD topology.
- **FR-2 / FR-3 / ADR-022** — Azure Blob Lease underlies both the v2 mgmt
  singleton and the v3 Terraform state lock (FR-V3-03); operational
  experience with leases carries over directly.
- **FR-24 / ADR-008-v2** — Cosign + Kyverno supply-chain enforcement is
  unchanged; v3 adds checkov as a complementary IaC-side gate.
- **ADR-016** — Sonar placement constraint (no `mgmt-we`) constrains
  FR-V3-25.
- **ADR-017** — Standby-controllers-at-zero pattern is not affected by v3.

---

## Risks and Mitigations

| # | Risk | Mitigation |
|---|---|---|
| R-1 | **State corruption** during the migration from local to remote backend (state import errors, lost resources) | Bootstrap the state SA out-of-band; perform per-env migration in a maintenance window with a fresh `terraform state pull` snapshot taken immediately before and after; enable blob versioning on the SA so any single bad state push is recoverable; rehearse on `dev` first |
| R-2 | **Sensitive value persisted into state** despite AKV sourcing (provider quirks, complex outputs) | Combine FR-V3-08 (no defaults), FR-V3-09 (OIDC-federated `TF_VAR_*`), and audit by `terraform state pull \| grep -iE 'password\|secret\|token\|key'` in CI; baseline known-acceptable entries; alert on new matches |
| R-3 | **Force-push breaks existing clones and downstream automation** when purging `tls.key` history | OQ-V3-03 schedules a coordinated cutover; pre-announce in two sprint cycles; provide a re-clone runbook; freeze merges during the window |
| R-4 | **Gate-adoption inertia** — contributors disable hooks locally or merge with `--no-verify` | Hooks enforced in CI as well as pre-commit (FR-V3-23); branch-protection requires status checks; periodic audit of merged commits for hook-bypass markers; office-hours session at each phase cutover |
| R-5 | **Sonar cost drift** if SaaS line-of-code billing grows unbounded | The hosting toggle (FR-V3-25) provides a self-hosted escape hatch on `cipool`; monthly cost review by the Platform team; LOC-based projection added to the FinOps dashboard pre-rollout |

---

## Success Metrics

- **100% of platform PRs gated** (fmt + validate + tflint) by end of sprint
  that closes P1 phase.
- **0 open P0 findings** by GA of v3 (F-01, F-05, F-06, F-07 fully closed
  and verified).
- **0 sensitive defaults** detected by the in-CI `terraform state pull`
  scanner for two consecutive sprints.
- **100% of state files** following the `tfstate/<env>/<cluster>.tfstate`
  key convention; zero state files outside the convention.
- **Checkov findings on baseline trend negative** week-over-week from
  sprint-2 onward; new findings rate < 5 per sprint.
- **Variable validation coverage** at 100% by end of sprint-2 after P1
  closure; ratchet visible in the custom tflint rule output.
- **New-code coverage > 80%** for `packages/backend` for two consecutive
  sprints after the gate becomes blocking.
- **Zero `uuid()` occurrences** in Terraform after P2 closure; consecutive
  `terraform plan` runs produce empty diffs.
- **Terraform version pin enforced** — CI rejects any module declaring a
  required version other than `~> 1.5.0`.
- **Mean time from PR open to plan posted** under 5 minutes on the GHA
  matrix (per env-state).

---
