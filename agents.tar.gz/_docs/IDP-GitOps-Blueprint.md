# Production-Grade GitOps & Platform Engineering Blueprint

**Stack:** Jira · Bitbucket · Jenkins · Crossplane (Azure Provider) · Azure AKS · ArgoCD · Azure Key Vault · External Secrets Operator
**Author Role:** Principal Enterprise Architect / Platform Engineering Specialist
**Document Version:** 1.0
**Reference Implementation:** [Azure-Samples/aks-platform-engineering](https://github.com/Azure-Samples/aks-platform-engineering)

---

## Executive Summary

This blueprint defines a **resilient, multi-cluster, multi-region Internal Developer Platform (IDP)** built on the GitOps Bridge pattern. The architecture isolates the *control plane* (Crossplane + ArgoCD hub) from the *data plane* (workload AKS clusters) and isolates the *developer experience plane* (Jira/Bitbucket/Jenkins) from runtime reconciliation, so that a failure in CI, the issue tracker, or even an entire region cannot stop already-running workloads or GitOps drift correction.

Decisions captured in this document:

- **Jenkins** is selected over Bamboo for the CI engine (justification in §3).
- **Crossplane** Azure provider acts as the cloud control plane, replacing Terraform for day-2 cloud provisioning.
- **ArgoCD ApplicationSet** in Hub-and-Spoke topology with sync waves orders Crossplane → ESO → Workloads.
- **External Secrets Operator with Azure Workload Identity** removes long-lived credentials from every cluster.
- **Multi-region active/active** management cluster pair (West Europe primary, North Europe DR) with Velero-replicated etcd snapshots and Git as the ultimate source of truth.

---

# 1. ARCHITECTURAL TOPOLOGY & FAILURE DOMAINS

## 1.1 Topology Overview

The platform is structured as **three planes** layered over **two Azure regions**:

| Plane | Purpose | Components | Failure Class |
|---|---|---|---|
| Developer Experience (DX) | Author intent | Jira, Bitbucket, Jenkins controller | *Convenience-critical* — outage stops new changes, not running workloads |
| Control Plane (CP) | Reconcile intent → state | Management AKS cluster (Crossplane, ArgoCD hub, ESO operator-of-operators) | *Reconciliation-critical* — outage freezes drift correction, workloads keep serving |
| Data Plane (DP) | Run workloads | Workload AKS clusters per env × region | *Runtime-critical* — direct user impact |

The cardinal rule: **state lives in Git, not in any cluster**. Any plane can be destroyed and rebuilt from the Bitbucket monorepo `platform-gitops` (Crossplane XRs, ArgoCD Applications, ESO ExternalSecrets, Helm value overlays).

## 1.2 Multi-Region, Multi-Cluster Layout

```
                                                  REGION: West Europe (Primary)               REGION: North Europe (DR / Active-Active for stateless)
┌─────────────────────┐                          ┌────────────────────────────────────┐      ┌────────────────────────────────────┐
│  DX Plane (SaaS)    │                          │  Management Cluster (mgmt-we)      │      │  Management Cluster (mgmt-ne)      │
│  ─ Jira Cloud       │  ── Webhook ────────►    │  ─ ArgoCD Hub (HA, 3 replicas)     │◄────►│  ─ ArgoCD Hub (warm standby)       │
│  ─ Bitbucket Cloud  │  ── Git pull ◄────────   │  ─ Crossplane + Azure provider     │      │  ─ Crossplane (read-only mode)     │
│  ─ Jenkins ctrl     │  ── kubectl ─────────►   │  ─ ESO controller (cluster-wide)   │      │  ─ ESO controller                  │
│   (HA, 2 replicas)  │     (ephemeral agents)   │  ─ Velero (etcd + PV backup)       │      │  ─ Velero restore target           │
└─────────────────────┘                          └────────────────────────────────────┘      └────────────────────────────────────┘
                                                         │  pushes XRs, watches CRDs
                                                         ▼
                                                  ┌───────────────────┬────────────────────┬───────────────────────┐
                                                  │ Workload AKS dev  │ Workload AKS stg   │ Workload AKS prod-we  │  Workload AKS prod-ne
                                                  │ (single AZ)       │ (multi-AZ)         │ (multi-AZ, prem SKU)  │  (multi-AZ, prem SKU)
                                                  │ ArgoCD agent      │ ArgoCD agent       │ ArgoCD agent          │  ArgoCD agent
                                                  │ ESO agent         │ ESO agent          │ ESO agent             │  ESO agent
                                                  │ App workloads     │ App workloads      │ App workloads         │  App workloads
                                                  └───────────────────┴────────────────────┴───────────────────────┴────────────────────
```

The full C4 Container diagram is delivered in `IDP-C4-Container.drawio` (built using the drawio-master-skill house style — see §1.6).

## 1.3 Failure Domain Isolation

| Failure Scenario | What Stops | What Keeps Working | Why |
|---|---|---|---|
| Jira Cloud down | New service-creation requests via portal | All existing pipelines, all running workloads, ArgoCD reconcile | Jira is *upstream of intent*; once a repo exists, it has no runtime dependency |
| Bitbucket Cloud down | New commits, CI triggers, ArgoCD *pulls* | Running workloads, in-flight reconciliations using last-cached manifests | ArgoCD caches the latest known-good revision; Crossplane reconciles from in-cluster CRs |
| Jenkins controller down | Image builds, new image-tag PRs | Existing images already in ACR; ArgoCD continues syncing whatever is in Git | CI is *write-side* only — read path (ArgoCD pull) is independent |
| Management cluster (mgmt-we) down | Drift correction for *new* changes, new Crossplane provisioning | All workload pods, in-region database connections | Workload clusters run independently; ArgoCD only intervenes during sync |
| Single workload cluster down | Workloads on that cluster | All other clusters, control plane, CI | Per-cluster blast radius; per-env clusters prevent cross-env contagion |
| Entire West Europe region down | West Europe workloads + primary mgmt | North Europe workloads; mgmt-ne promoted in DR runbook (§7) | Active-passive mgmt; active-active workloads via Front Door |

**Critical design rule:** the Crossplane management cluster **must not host any workload pods**. It is a "control plane only" cluster — taints + admission policies (Gatekeeper) reject non-platform workloads. This means an outage of the management cluster degrades the *meta-capability* of provisioning, not the *capability* of serving traffic.

## 1.4 Network Topology — Zero-Trust Segmentation

```
                                Azure Tenant
┌────────────────────────────────────────────────────────────────────────────────────┐
│  Hub VNet (10.0.0.0/16) — West Europe                                              │
│  ┌──────────────────────────────────────────────────────────────────────────────┐  │
│  │  Azure Firewall Premium  ─  egress + DNAT for inbound from Bitbucket webhooks│  │
│  │  Azure Bastion         ─  break-glass SSH/RDP (no public IPs anywhere else)  │  │
│  │  Private DNS Zones     ─  privatelink.vaultcore.azure.net,                    │  │
│  │                            privatelink.database.windows.net,                  │  │
│  │                            privatelink.documents.azure.com,                   │  │
│  │                            privatelink.servicebus.windows.net,                │  │
│  │                            privatelink.azurecr.io                             │  │
│  └──────────────────────────────────────────────────────────────────────────────┘  │
└──────────┬───────────────────────────────────────────────┬─────────────────────────┘
           │ VNet Peering                                  │ VNet Peering
           ▼                                               ▼
┌──────────────────────────────┐               ┌────────────────────────────────────┐
│ Spoke: Management (10.1/16)  │               │ Spoke: Workload-Prod (10.2/16)     │
│ ─ AKS API server: PRIVATE    │               │ ─ AKS API server: PRIVATE          │
│   (no public FQDN exposed)   │               │   (private cluster, authorized IPs │
│ ─ Crossplane, ArgoCD pods    │               │     restricted to mgmt subnet)     │
│ ─ Jenkins agent pool         │               │ ─ Workload pods only               │
│ ─ Private endpoints to:      │               │ ─ Private endpoints to AKV, SQL,   │
│     ACR, Bitbucket           │               │     Cosmos, Service Bus            │
│     (via Private Link Mesh)  │               │                                    │
└──────────────────────────────┘               └────────────────────────────────────┘

Inter-region: Global VNet Peering hub-we ↔ hub-ne, with route tables that prefer local
              endpoints and fail over via BGP/Front Door for North-bound traffic.
```

Concrete enforcement:

- **AKS clusters: private only.** `--enable-private-cluster --disable-public-fqdn`. API server reachable only via the hub.
- **Bitbucket → Jenkins:** webhook ingress arrives at Azure Front Door with a WAF rule pinning source CIDRs to Atlassian's published ranges, then DNAT'd through the firewall to the Jenkins controller.
- **Jenkins → AKS API:** kubectl traffic from the Jenkins agent pool (which runs *inside* the management AKS cluster — see §3.3) targets the private API server over the cluster's own pod network. There is no off-cluster path.
- **ArgoCD → workload cluster API:** for the hub-spoke model, ArgoCD authenticates via short-lived AAD tokens minted by workload-identity federation; the API server endpoint is reached over the peered VNet. **No kubeconfigs with static tokens are stored anywhere.**
- **Crossplane → Azure ARM:** outbound through Azure Firewall using a workload-identity-federated service principal. No client secrets.
- **All PaaS (AKV, SQL, Cosmos, Service Bus, ACR):** public access disabled, traffic through Private Endpoints, resolved by hub Private DNS Zones linked to all spokes.

## 1.5 Comparison vs. Reference Architecture

The Azure-Samples `aks-platform-engineering` reference uses a single-region management cluster bootstrapped by Terraform with a choice of Crossplane *or* CAPZ. This blueprint extends it by:

1. Promoting Crossplane to the sole provisioning engine for richer XRD abstraction (the reference treats Crossplane and CAPZ as equivalents; for true platform-engineering self-service, Crossplane's composition model is the better fit).
2. Adding a second management cluster (mgmt-ne) for management-plane DR — the reference does not address mgmt-cluster loss.
3. Pinning all PaaS to Private Endpoints — the reference does not enforce private networking by default.
4. Adding ESO + Workload Identity as the canonical secret pipeline; the reference leaves secret handling implicit.

## 1.6 C4 Container Diagram

The full C4 Container diagram is delivered as `IDP-C4-Container.drawio`. It follows the canonical house style: layered bands (Actors → DX Gateway → Management Plane → Data Plane → Adapters → Azure PaaS → Legend), source-colored orthogonal edges, and per-environment color coding (Dev = blue, Staging = purple, Prod = orange, External Azure = red). Open in draw.io desktop or diagrams.net to edit.

---

# 2. JIRA & BITBUCKET PLATFORM ENGINEERING GATEWAYS

## 2.1 "Create New IDP Service" — End-to-End Workflow

The platform exposes a single Jira issue type, **"IDP Service Request"**, with a custom screen capturing: service name, team, runtime (Node/Go/JVM/Python), data tier (none/SQL/Cosmos), messaging (none/Service Bus), and SLO class (bronze/silver/gold). Workflow states drive automation:

```
[OPEN]
  │  (assigned)
  ▼
[IN_REVIEW]                  ← Platform-Eng approver checks naming, cost, capacity
  │  (transition: Approve)
  ▼
[SCAFFOLDING]                ← Automation rule: webhook → Jenkins seed job
  │  (Jenkins reports success via REST)
  ▼
[REPO_PROVISIONED]           ← Bitbucket repo + branch protection + CODEOWNERS in place
  │  (ArgoCD ApplicationSet picks up new dir → first deploy to dev)
  ▼
[DEPLOYED_DEV]               ← ArgoCD webhook → Jira transition
  │  (Manual transition to PROMOTE)
  ▼
[DEPLOYED_PROD]
  │
  ▼
[CLOSED]
```

### 2.1.1 Trigger Mechanism — Jira Automation Rule

```yaml
# Jira Automation rule (exported from Jira Cloud)
name: "IDP-Service-Scaffold-On-Approval"
trigger:
  type: "issue.transitioned"
  condition:
    project: "IDP"
    issueType: "IDP Service Request"
    toStatus: "SCAFFOLDING"
actions:
  - type: "webhook"
    method: POST
    url: "https://jenkins.idp.example.com/generic-webhook-trigger/invoke?token={{secret.JENKINS_SEED_TOKEN}}"
    headers:
      Content-Type: "application/json"
    body: |
      {
        "ticketKey": "{{issue.key}}",
        "serviceName": "{{issue.fields.customfield_10001}}",
        "team": "{{issue.fields.customfield_10002}}",
        "runtime": "{{issue.fields.customfield_10003}}",
        "dataTier": "{{issue.fields.customfield_10004}}",
        "messaging": "{{issue.fields.customfield_10005}}",
        "sloClass": "{{issue.fields.customfield_10006}}",
        "requesterEmail": "{{issue.reporter.emailAddress}}"
      }
```

### 2.1.2 Jenkins Seed Job — Scaffolding

The seed job is a Jenkinsfile in the platform monorepo at `seed/Jenkinsfile.scaffold-service`. It uses Bitbucket's REST API to create the repo, apply the template, set branch protections, and register the new app with the ArgoCD ApplicationSet generator.

```groovy
pipeline {
  agent { label 'platform-seed' }
  parameters {
    string(name: 'ticketKey',    defaultValue: '', description: 'Jira ticket key')
    string(name: 'serviceName',  defaultValue: '', description: 'kebab-case service name')
    string(name: 'team',         defaultValue: '', description: 'Owning team slug')
    string(name: 'runtime',      defaultValue: 'node', description: 'node|go|jvm|python')
    string(name: 'dataTier',     defaultValue: 'none', description: 'none|sql|cosmos')
    string(name: 'messaging',    defaultValue: 'none', description: 'none|servicebus')
    string(name: 'sloClass',     defaultValue: 'silver', description: 'bronze|silver|gold')
    string(name: 'requesterEmail', defaultValue: '')
  }
  environment {
    BITBUCKET_WORKSPACE = 'platform-prod'
    PLATFORM_GITOPS_REPO = 'platform-gitops'
    JIRA_BASE = 'https://example.atlassian.net'
  }
  stages {
    stage('Validate input') {
      steps {
        script {
          assert params.serviceName ==~ /^[a-z][a-z0-9-]{2,32}$/ : "serviceName invalid"
          assert params.runtime in ['node','go','jvm','python']
          assert params.dataTier in ['none','sql','cosmos']
        }
      }
    }
    stage('Create Bitbucket repository') {
      steps {
        withCredentials([usernamePassword(credentialsId: 'bitbucket-app-password',
                                          usernameVariable: 'BB_USER',
                                          passwordVariable: 'BB_TOKEN')]) {
          sh '''
            curl -sS -u "$BB_USER:$BB_TOKEN" -X POST \
              "https://api.bitbucket.org/2.0/repositories/${BITBUCKET_WORKSPACE}/${serviceName}" \
              -H "Content-Type: application/json" \
              -d "{\\"scm\\":\\"git\\",\\"is_private\\":true,\\"project\\":{\\"key\\":\\"IDP\\"}}"
          '''
        }
      }
    }
    stage('Apply template (Cookiecutter)') {
      steps {
        sh '''
          cookiecutter templates/${runtime}-service \
            --no-input \
            service_name=${serviceName} \
            team=${team} \
            data_tier=${dataTier} \
            messaging=${messaging} \
            slo_class=${sloClass} \
            -o /tmp/scaffold
          cd /tmp/scaffold/${serviceName}
          git init && git remote add origin git@bitbucket.org:${BITBUCKET_WORKSPACE}/${serviceName}.git
          git add . && git -c user.email=ci@platform -c user.name=PlatformBot commit -m "${ticketKey}: scaffold ${serviceName}"
          git push -u origin main
        '''
      }
    }
    stage('Apply branch protection + CODEOWNERS') {
      steps {
        withCredentials([usernamePassword(credentialsId: 'bitbucket-app-password',
                                          usernameVariable: 'BB_USER',
                                          passwordVariable: 'BB_TOKEN')]) {
          sh '''
            curl -sS -u "$BB_USER:$BB_TOKEN" -X POST \
              "https://api.bitbucket.org/2.0/repositories/${BITBUCKET_WORKSPACE}/${serviceName}/branch-restrictions" \
              -H "Content-Type: application/json" \
              -d @- <<EOF
            { "kind": "require_approvals_to_merge", "pattern": "main", "value": 2 }
            EOF
            curl -sS -u "$BB_USER:$BB_TOKEN" -X POST \
              "https://api.bitbucket.org/2.0/repositories/${BITBUCKET_WORKSPACE}/${serviceName}/branch-restrictions" \
              -H "Content-Type: application/json" \
              -d '{ "kind": "require_passing_builds_to_merge", "pattern": "main", "value": 1 }'
            curl -sS -u "$BB_USER:$BB_TOKEN" -X POST \
              "https://api.bitbucket.org/2.0/repositories/${BITBUCKET_WORKSPACE}/${serviceName}/branch-restrictions" \
              -H "Content-Type: application/json" \
              -d '{ "kind": "force", "pattern": "main" }'
          '''
        }
      }
    }
    stage('Register with platform-gitops (ApplicationSet generator)') {
      steps {
        sh '''
          git clone git@bitbucket.org:${BITBUCKET_WORKSPACE}/${PLATFORM_GITOPS_REPO}.git /tmp/gitops
          cd /tmp/gitops
          mkdir -p apps/${serviceName}/{base,overlays/dev,overlays/staging,overlays/prod}
          envsubst < templates/app-base.yaml.tpl > apps/${serviceName}/base/kustomization.yaml
          # Crossplane Composite Resource Claim (depends on dataTier/messaging)
          envsubst < templates/xrc-${dataTier}.yaml.tpl > apps/${serviceName}/base/xrc-data.yaml || true
          envsubst < templates/xrc-${messaging}.yaml.tpl > apps/${serviceName}/base/xrc-msg.yaml || true
          git checkout -b feat/${ticketKey}-onboard-${serviceName}
          git add . && git -c user.email=ci@platform commit -m "${ticketKey}: onboard ${serviceName}"
          git push origin feat/${ticketKey}-onboard-${serviceName}
          # Open Bitbucket PR via API (auto-merged by Platform owners after review)
        '''
      }
    }
    stage('Report to Jira') {
      steps {
        withCredentials([string(credentialsId: 'jira-token', variable: 'JIRA_TOKEN')]) {
          sh '''
            curl -sS -u platform-bot:$JIRA_TOKEN -X POST \
              "$JIRA_BASE/rest/api/3/issue/${ticketKey}/transitions" \
              -H "Content-Type: application/json" \
              -d '{"transition":{"id":"31"}}'  # 31 = "Repo Provisioned"
          '''
        }
      }
    }
  }
  post {
    failure {
      withCredentials([string(credentialsId: 'jira-token', variable: 'JIRA_TOKEN')]) {
        sh '''
          curl -sS -u platform-bot:$JIRA_TOKEN -X POST \
            "$JIRA_BASE/rest/api/3/issue/${ticketKey}/comment" \
            -H "Content-Type: application/json" \
            -d "{\\"body\\":\\"Scaffold failed: see ${BUILD_URL}\\"}"
        '''
      }
    }
  }
}
```

## 2.2 Governance Model

### 2.2.1 Branch Protection (enforced at scaffold time, audited weekly)

| Rule | Pattern | Enforcement |
|---|---|---|
| Require 2 approvals to merge | `main`, `release/*` | Bitbucket branch-restriction `require_approvals_to_merge` |
| Require passing builds | `main`, `release/*` | `require_passing_builds_to_merge` |
| Require approval from CODEOWNERS | `main` | `require_default_reviewer_approvals_to_merge` value=1 |
| Prohibit force push | `main`, `release/*` | `force` rule |
| Prohibit branch deletion | `main`, `release/*` | `delete` rule |
| Require resolved tasks | all | `require_tasks_to_be_completed` |

### 2.2.2 CODEOWNERS Template

```
# /CODEOWNERS — generated by scaffolder
*                           @platform-prod/security-reviewers
/k8s/                       @platform-prod/platform-engineers
/infra/crossplane/          @platform-prod/platform-engineers
/Jenkinsfile                @platform-prod/ci-reviewers
/src/                       @{{team}}
```

### 2.2.3 Mandatory Security-Scan Insertion Points (per pipeline)

| Stage | Scanner | Block on |
|---|---|---|
| PR opened | Bitbucket Pipelines pre-merge: `gitleaks` (secrets), `semgrep ci` (SAST), `trivy fs` (deps) | Any HIGH/CRITICAL |
| Pre-build | Jenkins: `trivy fs --severity HIGH,CRITICAL --exit-code 1` | HIGH+CRITICAL |
| Post-build | `trivy image` on built OCI artifact | HIGH+CRITICAL |
| Pre-push to ACR | `cosign sign` with KMS key | Signature mandatory |
| In-cluster admission | OPA/Gatekeeper: `require-cosign-signed-image` policy | Unsigned images rejected at AKS admission |

## 2.3 Tracking Drift and Rollbacks in Jira (ArgoCD → Jira)

ArgoCD emits Notifications via webhook to a small adapter service (`argocd-jira-bridge`) running in the management cluster. The bridge translates ArgoCD events to Jira issues/transitions.

```yaml
# argocd-cm: notifications template
apiVersion: v1
kind: ConfigMap
metadata:
  name: argocd-notifications-cm
  namespace: argocd
data:
  service.webhook.jira-bridge: |
    url: http://argocd-jira-bridge.argocd.svc:8080/event
    headers:
    - name: Content-Type
      value: application/json
  template.app-degraded: |
    webhook:
      jira-bridge:
        method: POST
        body: |
          {
            "kind": "drift_or_degradation",
            "app": "{{.app.metadata.name}}",
            "namespace": "{{.app.spec.destination.namespace}}",
            "cluster": "{{.app.spec.destination.name}}",
            "health": "{{.app.status.health.status}}",
            "sync": "{{.app.status.sync.status}}",
            "revision": "{{.app.status.sync.revision}}",
            "owner": "{{index .app.metadata.labels "owner"}}"
          }
  template.app-rolled-back: |
    webhook:
      jira-bridge:
        method: POST
        body: |
          {
            "kind": "rollback",
            "app": "{{.app.metadata.name}}",
            "fromRevision": "{{.app.status.operationState.operation.sync.revision}}",
            "toRevision": "{{.app.status.history (index .app.status.history (sub (len .app.status.history) 2)).revision}}",
            "reason": "{{.app.status.operationState.message}}",
            "owner": "{{index .app.metadata.labels "owner"}}"
          }
  trigger.on-degraded: |
    - when: app.status.health.status == 'Degraded'
      send: [app-degraded]
  trigger.on-rollback: |
    - when: app.status.operationState.phase == 'Succeeded' and app.status.operationState.operation.sync.prune == false and (app.status.history | len) > 1
      send: [app-rolled-back]
```

The bridge then:

- Drift / degradation → opens a new Jira incident (`IDP-DRIFT-<n>`) labeled with the owning team, links it to the originating service's Jira project.
- Rollback → comments on the active deploy ticket and transitions it to `ROLLED_BACK`.
- Sync recovered → auto-resolves the drift incident.

## 2.4 Workflow — PlantUML Activity Diagram

```plantuml
@startuml
title IDP Service Onboarding — Jira → Bitbucket → ArgoCD
skinparam activity {
  BackgroundColor #D6E4F0
  BorderColor #2B579A
  FontName Helvetica
}
skinparam swimlane {
  BorderColor #2B579A
}

|#FFF4E8|Developer|
start
:Create Jira ticket "IDP Service Request";
:Fill in service name, runtime,\ndata tier, messaging, SLO class;

|#D6E4F0|Platform Engineer|
:Review request\n(naming, cost, capacity);
if (Approve?) then (yes)
  :Transition to SCAFFOLDING;
else (no)
  :Comment + transition to REJECTED;
  stop
endif

|#E8D5E8|Jira Automation|
:Fire webhook to Jenkins\nseed job with form payload;

|#F1F3F4|Jenkins (Seed Job)|
:Validate input (regex on name,\nenum on runtime);
:Create Bitbucket repo via API;
:Apply Cookiecutter template;
:git push initial commit;
:Apply branch protections\n(2 approvals, passing builds,\nno force push);
:Add CODEOWNERS;
:Clone platform-gitops repo;
:Add apps/<svc>/{base,overlays/...};
:Open PR for ApplicationSet to pick up;
:Transition Jira → REPO_PROVISIONED;

|#FFF4E8|Platform Engineer|
:Review platform-gitops PR;
:Merge to main;

|#FCE8E6|ArgoCD ApplicationSet|
:Generator detects new directory;
:Render Application for dev cluster;
:Sync wave 0: Crossplane XRs;
:Sync wave 1: ESO ExternalSecrets;
:Sync wave 2: workload Deployment;

|#D6E4F0|ArgoCD Notifications|
:Webhook → argocd-jira-bridge;
:Bridge transitions Jira → DEPLOYED_DEV;

|#FFF4E8|Developer|
:Validate in dev;
:Open PR to promote to staging\n(updates overlay image tag);
note right
  Promotions are simple Git PRs;
  ArgoCD picks them up automatically.
end note
stop
@enduml
```

---

# 3. RESILIENT CI PIPELINE ENGINE DESIGN

## 3.1 Jenkins vs. Bamboo — Justified Choice: **Jenkins**

| Criterion | Jenkins | Bamboo | Winner for this stack |
|---|---|---|---|
| Kubernetes-native ephemeral agents | First-class via `kubernetes-plugin` (pod-per-build, auto-cleanup) | Possible but bolted on; requires Bamboo Remote Agents in pods, less polished | **Jenkins** |
| GitOps-friendly pipeline definition | Jenkinsfile in repo, declarative, widely understood | Bamboo Specs in Java/YAML, less ergonomic, smaller community | **Jenkins** |
| HA controller | Active-active impossible; active-passive with shared `$JENKINS_HOME` PVC + leader election | Active-Passive Bamboo Data Center available but costs more, smaller install base | **Jenkins** (cheaper, well-trodden HA pattern) |
| Plugin ecosystem for Crossplane / Cosign / Trivy / ACR | All have stable plugins or shell-callable CLIs | Smaller plugin ecosystem; usually shell-out anyway | **Jenkins** |
| Failure-domain isolation | Controller runs in mgmt cluster as a StatefulSet; agents spin up per job in a separate node pool | Same achievable but with more configuration overhead | **Jenkins** |
| Atlassian licensing dependency | Independent — outage of Atlassian Cloud does not stop Jenkins | Bamboo is Atlassian — couples CI failure domain to Jira/Bitbucket SaaS | **Jenkins** (critical for failure-domain isolation goal) |
| Cost at scale | Free (OSS); pay for compute only | Per-agent licensing | **Jenkins** |

The **decisive argument** is failure-domain isolation: this blueprint's #1 design goal is that a Jira/Bitbucket SaaS outage must not freeze the CI plane's ability to release security patches via mirrored repos. Bamboo, being inside the Atlassian product family and operationally entangled with Bitbucket Cloud's webhook delivery, doubles the blast radius of an Atlassian incident. Jenkins decouples this.

## 3.2 Resilient Declarative Pipeline (Jenkinsfile Outline)

```groovy
pipeline {
  agent none  // each stage pins its own ephemeral pod template
  options {
    timeout(time: 30, unit: 'MINUTES')
    buildDiscarder(logRotator(numToKeepStr: '50'))
    disableConcurrentBuilds()  // per-branch concurrency; PRs scale via PR-builder
    retry(2)  // controller restart safety
  }
  environment {
    SERVICE_NAME = "${env.JOB_NAME.split('/')[1]}"
    ACR_NAME     = "acrplatformprod"
    ACR_LOGIN    = "${ACR_NAME}.azurecr.io"
    COSIGN_KEY   = "azurekms://platform-kv.vault.azure.net/cosign-signing-key"
    GITOPS_REPO  = "git@bitbucket.org:platform-prod/platform-gitops.git"
    GITOPS_PATH  = "apps/${SERVICE_NAME}/overlays/dev"
  }
  stages {
    stage('Checkout') {
      agent { kubernetes { yamlFile 'ci/pod-templates/checkout.yaml' } }
      steps {
        checkout scm
        stash includes: '**', name: 'src'
      }
    }
    stage('Lint & SAST') {
      parallel {
        stage('Lint') {
          agent { kubernetes { yamlFile 'ci/pod-templates/node.yaml' } }
          steps {
            unstash 'src'
            sh 'npm ci --no-audit --no-fund && npm run lint'
          }
        }
        stage('SAST') {
          agent { kubernetes { yamlFile 'ci/pod-templates/semgrep.yaml' } }
          steps {
            unstash 'src'
            sh 'semgrep ci --config=auto --error'
          }
        }
        stage('Dependency Scan') {
          agent { kubernetes { yamlFile 'ci/pod-templates/trivy.yaml' } }
          steps {
            unstash 'src'
            sh 'trivy fs --severity HIGH,CRITICAL --exit-code 1 --no-progress .'
          }
        }
      }
    }
    stage('Build OCI Image (Buildah, rootless)') {
      agent { kubernetes { yamlFile 'ci/pod-templates/buildah.yaml' } }
      steps {
        unstash 'src'
        script {
          env.IMAGE_TAG = "${env.BRANCH_NAME}-${env.GIT_COMMIT.take(7)}-${env.BUILD_NUMBER}"
        }
        sh '''
          buildah bud --layers --format=oci \
            --label org.opencontainers.image.revision=${GIT_COMMIT} \
            --label org.opencontainers.image.source=${GIT_URL} \
            -t ${ACR_LOGIN}/${SERVICE_NAME}:${IMAGE_TAG} .
        '''
      }
    }
    stage('Image Vulnerability Scan') {
      agent { kubernetes { yamlFile 'ci/pod-templates/trivy.yaml' } }
      steps {
        sh '''
          trivy image --severity HIGH,CRITICAL --exit-code 1 --no-progress \
            --ignore-unfixed ${ACR_LOGIN}/${SERVICE_NAME}:${IMAGE_TAG}
        '''
      }
    }
    stage('Push to ACR') {
      agent { kubernetes { yamlFile 'ci/pod-templates/buildah.yaml' } }
      steps {
        // Azure Workload Identity federation — no client secret in Jenkins
        sh '''
          az login --service-principal -u $AZURE_CLIENT_ID \
            --tenant $AZURE_TENANT_ID --federated-token $(cat /var/run/secrets/azure/tokens/azure-identity-token)
          az acr login -n ${ACR_NAME}
          buildah push ${ACR_LOGIN}/${SERVICE_NAME}:${IMAGE_TAG}
        '''
      }
    }
    stage('Sign Image (Cosign + AKV)') {
      agent { kubernetes { yamlFile 'ci/pod-templates/cosign.yaml' } }
      steps {
        sh '''
          cosign sign --key ${COSIGN_KEY} ${ACR_LOGIN}/${SERVICE_NAME}:${IMAGE_TAG}
          cosign verify --key ${COSIGN_KEY} ${ACR_LOGIN}/${SERVICE_NAME}:${IMAGE_TAG}
        '''
      }
    }
    stage('SBOM') {
      agent { kubernetes { yamlFile 'ci/pod-templates/syft.yaml' } }
      steps {
        sh '''
          syft ${ACR_LOGIN}/${SERVICE_NAME}:${IMAGE_TAG} -o spdx-json > sbom.spdx.json
          cosign attest --predicate sbom.spdx.json --type spdx \
            --key ${COSIGN_KEY} ${ACR_LOGIN}/${SERVICE_NAME}:${IMAGE_TAG}
        '''
      }
    }
    stage('GitOps: Update dev overlay (idempotent, race-free)') {
      when { branch 'main' }
      agent { kubernetes { yamlFile 'ci/pod-templates/git.yaml' } }
      steps {
        sshagent(['gitops-deploy-key']) {
          sh '''
            set -euo pipefail
            git clone --depth 1 ${GITOPS_REPO} gitops
            cd gitops/${GITOPS_PATH}
            # Use kustomize edit, which is idempotent
            kustomize edit set image ${SERVICE_NAME}=${ACR_LOGIN}/${SERVICE_NAME}:${IMAGE_TAG}
            # Detect no-op (e.g., retry of same commit) and exit cleanly
            if git -C ../../.. diff --quiet; then
              echo "No image change; skipping commit"
              exit 0
            fi
            # Marker prevents recursive trigger loops
            git -c user.email=ci@platform -c user.name=PlatformBot \
              commit -am "[ci skip] ${SERVICE_NAME}: bump dev to ${IMAGE_TAG}"
            # Conflict-free push: rebase-and-retry up to 5 times
            for i in 1 2 3 4 5; do
              if git push origin main; then exit 0; fi
              git pull --rebase origin main
            done
            echo "Push failed after 5 retries — opening Jira incident"
            exit 1
          '''
        }
      }
    }
  }
  post {
    failure {
      // Notify Jira + Slack via shared library
      script { notifyFailure(env.SERVICE_NAME, env.BUILD_URL) }
    }
  }
}
```

## 3.3 Resilient GitOps Update — Avoiding Race Conditions and Commit Loops

Two failure modes get this wrong:

**Race condition 1 — concurrent CI runs push conflicting bumps.** Solved by the `for i in 1..5` rebase-and-push loop. Because `kustomize edit set image` is *idempotent* (writing the same tag twice produces no diff), a retry after a peer's commit simply re-applies our intended tag on top of the freshly pulled `main`.

**Race condition 2 — ArgoCD detects the new commit, syncs, somehow triggers more CI.** Solved by:

1. The commit message contains `[ci skip]` — Bitbucket Pipelines, Jenkins multibranch, and Bamboo all honor this convention.
2. The CI webhook filter on Jenkins explicitly excludes commits whose author is `PlatformBot` (a separate Bitbucket service account):

```xml
<!-- Jenkins multibranch: Bitbucket Branch Source plugin advanced filter -->
<traits>
  <com.cloudbees.jenkins.plugins.bitbucket.SkipNotificationsBranchPropertyStrategy_-DescriptorImpl/>
  <jenkins.scm.impl.trait.RegexSCMHeadFilterTrait>
    <regex>^(?!PlatformBot).*$</regex>  <!-- filter by author -->
  </jenkins.scm.impl.trait.RegexSCMHeadFilterTrait>
</traits>
```

3. ArgoCD sync **does not generate commits.** It pulls; only Jenkins or human PRs ever write to the GitOps repo. So even if ArgoCD reconciles, there's no commit to re-trigger CI.

The combination — idempotent `kustomize edit` + rebase loop + author-filter + `[ci skip]` — eliminates both classes of loop.

## 3.4 Agent Scaling and Recovery

Jenkins runs as a **two-replica StatefulSet** in the `jenkins` namespace of the management AKS cluster:

- **Controller storage:** Azure Premium SSD ReadWriteMany via Azure Files (with `nfs` protocol) for `$JENKINS_HOME`. The two replicas use leader election via the `kubernetes` plugin so one is always active.
- **Agent node pool:** a dedicated AKS node pool named `cipool` with the taint `workload=ci:NoSchedule`. Pod templates tolerate this taint; nothing else runs on it. The pool scales 1 → 30 via cluster autoscaler.
- **Per-job agents:** every stage's `agent { kubernetes { yamlFile … } }` instantiates a fresh pod (container with the right toolchain pre-built into the image). On job end, the pod is deleted — no state, no leakage.
- **Restart recovery:** if the controller dies mid-build, the Jenkins resume-on-restart feature picks up the build at the last completed stage. In-flight pods are reaped by Kubernetes garbage collection (ownerReference on the pod points to the build).

## 3.5 Pipeline Workflow Diagram (PlantUML)

```plantuml
@startuml
title CI Pipeline — Build, Sign, Update GitOps
skinparam ActivityBackgroundColor #D6E4F0
skinparam ActivityBorderColor #2B579A
skinparam ActivityDiamondBackgroundColor #FFF4E8
skinparam ArrowColor #2B579A
skinparam defaultFontName Helvetica

start
:Developer pushes commit to feature branch;
:Bitbucket webhook → Jenkins controller;
:Spawn ephemeral pod in 'cipool' node pool;

partition "Quality Gates (parallel)" {
  fork
    :Lint (npm/golangci/...);
  fork again
    :SAST (Semgrep);
  fork again
    :Dependency Scan (Trivy fs);
  end fork
}

if (Any gate failed?) then (yes)
  :Report to PR;
  stop
else (no)
endif

:Build OCI image with Buildah (rootless);
:Trivy image scan;

if (HIGH/CRITICAL CVE?) then (yes)
  :Fail build + notify owner;
  stop
else (no)
endif

:Azure WI login (federated, no secret);
:Push image to ACR;
:Cosign sign with AKV-backed key;
:Cosign attest SBOM (SPDX);

if (Branch == main?) then (yes)
  :Clone platform-gitops (depth=1);
  :kustomize edit set image (idempotent);
  while (git push) is (conflict)
    :git pull --rebase;
  endwhile (success)
  :Tag commit '[ci skip]' as PlatformBot;
else (no)
  :Stop — feature branches do not deploy;
  stop
endif

:ArgoCD detects new commit;
:Sync to dev cluster;
stop
@enduml
```

---

# 4. CROSSPLANE CLOUD CONTROL PLANE & AZURE CUSTOM RESOURCES

## 4.1 Composition Strategy

Crossplane runs in the management cluster with the **`provider-upjet-azure`** family (Upjet-generated Terraform-equivalent providers). Each PaaS service this platform offers is exposed as a **Composite Resource Definition (XRD)** — a CRD that abstracts a bundle of Azure primitives behind a small set of platform-relevant parameters. Application teams write **Composite Resource Claims (XRCs)** in their app namespace; Crossplane materializes them into Azure resources via Compositions.

Naming conventions: XRDs in API group `platform.example.com/v1alpha1`, claims namespaced to the app, composite resources cluster-scoped.

## 4.2 XRD #1 — Azure SQL Server + Database with Entra ID Authentication

```yaml
apiVersion: apiextensions.crossplane.io/v1
kind: CompositeResourceDefinition
metadata:
  name: xsqldatabases.platform.example.com
spec:
  group: platform.example.com
  names:
    kind: XSQLDatabase
    plural: xsqldatabases
  claimNames:
    kind: SQLDatabase
    plural: sqldatabases
  defaultCompositionRef:
    name: sqldatabase.azure.platform.example.com
  versions:
  - name: v1alpha1
    served: true
    referenceable: true
    schema:
      openAPIV3Schema:
        type: object
        properties:
          spec:
            type: object
            properties:
              parameters:
                type: object
                required: [serviceName, environment, sloClass, entraAdminGroupObjectId]
                properties:
                  serviceName: { type: string, pattern: '^[a-z][a-z0-9-]{2,32}$' }
                  environment: { type: string, enum: [dev, staging, prod] }
                  sloClass:    { type: string, enum: [bronze, silver, gold] }
                  region:      { type: string, default: westeurope }
                  entraAdminGroupObjectId: { type: string }
                  geoReplicaRegion:        { type: string }
                  keyVaultRef:
                    type: object
                    required: [name, namespace]
                    properties:
                      name:      { type: string }
                      namespace: { type: string }
            required: [parameters]
          status:
            type: object
            properties:
              connectionInfo:
                type: object
                properties:
                  serverFQDN:   { type: string }
                  databaseName: { type: string }
                  keyVaultSecretName: { type: string }
---
apiVersion: apiextensions.crossplane.io/v1
kind: Composition
metadata:
  name: sqldatabase.azure.platform.example.com
  labels: { provider: azure, service: sql }
spec:
  compositeTypeRef:
    apiVersion: platform.example.com/v1alpha1
    kind: XSQLDatabase
  writeConnectionSecretsToNamespace: crossplane-system
  resources:
  - name: resourceGroup
    base:
      apiVersion: azure.upbound.io/v1beta1
      kind: ResourceGroup
      spec:
        forProvider:
          location: westeurope
    patches:
    - fromFieldPath: spec.parameters.region
      toFieldPath: spec.forProvider.location
    - fromFieldPath: spec.parameters.serviceName
      toFieldPath: metadata.name
      transforms:
      - type: string
        string: { fmt: "rg-%s-sql" }
  - name: sqlServer
    base:
      apiVersion: sql.azure.upbound.io/v1beta1
      kind: MSSQLServer
      spec:
        forProvider:
          version: "12.0"
          minimumTlsVersion: "1.2"
          publicNetworkAccessEnabled: false
          identity:
            type: SystemAssigned
          azureadAdministrator:
          - loginUsername: "EntraAdmins"
            objectId: "REPLACED_BY_PATCH"
            azureadAuthenticationOnly: true   # Entra-only; no SQL logins
    patches:
    - fromFieldPath: spec.parameters.entraAdminGroupObjectId
      toFieldPath: spec.forProvider.azureadAdministrator[0].objectId
    - fromFieldPath: spec.parameters.region
      toFieldPath: spec.forProvider.location
    - fromFieldPath: spec.parameters.serviceName
      toFieldPath: metadata.name
      transforms:
      - { type: string, string: { fmt: "sql-%s-server" } }
    - fromFieldPath: metadata.uid
      toFieldPath: spec.writeConnectionSecretToRef.name
      transforms:
      - { type: string, string: { fmt: "%s-sql-conn" } }
  - name: sqlDatabase
    base:
      apiVersion: sql.azure.upbound.io/v1beta1
      kind: MSSQLDatabase
      spec:
        forProvider:
          collation: SQL_Latin1_General_CP1_CI_AS
          maxSizeGb: 32
          skuName: GP_S_Gen5_2     # serverless, overridden by sloClass patch
          zoneRedundant: false
    patches:
    - fromFieldPath: spec.parameters.serviceName
      toFieldPath: metadata.name
      transforms: [ { type: string, string: { fmt: "sql-%s-db" } } ]
    - fromFieldPath: spec.parameters.sloClass
      toFieldPath: spec.forProvider.skuName
      transforms:
      - type: map
        map:
          bronze: GP_S_Gen5_2
          silver: GP_Gen5_4
          gold:   BC_Gen5_8
    - fromFieldPath: spec.parameters.sloClass
      toFieldPath: spec.forProvider.zoneRedundant
      transforms:
      - type: map
        map: { bronze: "false", silver: "false", gold: "true" }
  - name: privateEndpoint
    base:
      apiVersion: network.azure.upbound.io/v1beta1
      kind: PrivateEndpoint
      spec:
        forProvider:
          subnetIdSelector:
            matchLabels: { role: pe-subnet }
          privateServiceConnection:
          - name: psc-sql
            isManualConnection: false
            subresourceNames: [ sqlServer ]
            privateConnectionResourceIdSelector:
              matchControllerRef: true
    patches:
    - fromFieldPath: spec.parameters.serviceName
      toFieldPath: metadata.name
      transforms: [ { type: string, string: { fmt: "pe-sql-%s" } } ]
  - name: pushConnInfoToKV
    base:
      apiVersion: keyvault.azure.upbound.io/v1beta1
      kind: Secret
      spec:
        forProvider:
          contentType: "application/json"
          keyVaultIdSelector:
            matchLabels: { role: platform-kv }
    patches:
    - fromFieldPath: spec.parameters.serviceName
      toFieldPath: metadata.name
      transforms: [ { type: string, string: { fmt: "%s-sql-conn" } } ]
    - fromFieldPath: spec.parameters.serviceName
      toFieldPath: spec.forProvider.name
      transforms: [ { type: string, string: { fmt: "%s-sql-conn" } } ]
    - type: CombineFromComposite
      combine:
        variables:
        - fromFieldPath: status.atProvider.fullyQualifiedDomainName  # from MSSQLServer
        - fromFieldPath: spec.parameters.serviceName
        strategy: string
        string: { fmt: '{"server":"%s","database":"sql-%s-db","authMode":"AAD-Integrated"}' }
      toFieldPath: spec.forProvider.value
```

## 4.3 XRD #2 — Cosmos DB (SQL API) with Failover

```yaml
apiVersion: apiextensions.crossplane.io/v1
kind: CompositeResourceDefinition
metadata:
  name: xcosmosaccounts.platform.example.com
spec:
  group: platform.example.com
  names: { kind: XCosmosAccount, plural: xcosmosaccounts }
  claimNames: { kind: CosmosAccount, plural: cosmosaccounts }
  defaultCompositionRef: { name: cosmos.azure.platform.example.com }
  versions:
  - name: v1alpha1
    served: true
    referenceable: true
    schema:
      openAPIV3Schema:
        type: object
        properties:
          spec:
            type: object
            properties:
              parameters:
                type: object
                required: [serviceName, primaryRegion, sloClass]
                properties:
                  serviceName:        { type: string }
                  primaryRegion:      { type: string, default: westeurope }
                  failoverRegion:     { type: string, default: northeurope }
                  sloClass:           { type: string, enum: [bronze, silver, gold] }
                  databaseName:       { type: string, default: appdb }
                  containers:
                    type: array
                    items:
                      type: object
                      required: [name, partitionKey]
                      properties:
                        name:         { type: string }
                        partitionKey: { type: string }
                        throughput:   { type: integer, default: 400 }
---
apiVersion: apiextensions.crossplane.io/v1
kind: Composition
metadata:
  name: cosmos.azure.platform.example.com
spec:
  compositeTypeRef:
    apiVersion: platform.example.com/v1alpha1
    kind: XCosmosAccount
  resources:
  - name: cosmosAccount
    base:
      apiVersion: cosmosdb.azure.upbound.io/v1beta1
      kind: Account
      spec:
        forProvider:
          kind: GlobalDocumentDB                 # SQL API
          offerType: Standard
          consistencyPolicy:
          - consistencyLevel: Session
          automaticFailoverEnabled: true
          multipleWriteLocationsEnabled: false
          publicNetworkAccessEnabled: false
          backup:
          - type: Continuous
          geoLocation:
          - location: westeurope
            failoverPriority: 0
          - location: northeurope
            failoverPriority: 1
    patches:
    - fromFieldPath: spec.parameters.serviceName
      toFieldPath: metadata.name
      transforms: [ { type: string, string: { fmt: "cosmos-%s" } } ]
    - fromFieldPath: spec.parameters.primaryRegion
      toFieldPath: spec.forProvider.geoLocation[0].location
    - fromFieldPath: spec.parameters.failoverRegion
      toFieldPath: spec.forProvider.geoLocation[1].location
    - fromFieldPath: spec.parameters.sloClass
      toFieldPath: spec.forProvider.consistencyPolicy[0].consistencyLevel
      transforms:
      - type: map
        map:
          bronze: Eventual
          silver: Session
          gold:   BoundedStaleness
  - name: cosmosDatabase
    base:
      apiVersion: cosmosdb.azure.upbound.io/v1beta1
      kind: SQLDatabase
      spec:
        forProvider:
          accountNameSelector: { matchControllerRef: true }
          resourceGroupNameSelector: { matchControllerRef: true }
    patches:
    - fromFieldPath: spec.parameters.databaseName
      toFieldPath: spec.forProvider.name
  - name: privateEndpoint
    base:
      apiVersion: network.azure.upbound.io/v1beta1
      kind: PrivateEndpoint
      spec:
        forProvider:
          subnetIdSelector: { matchLabels: { role: pe-subnet } }
          privateServiceConnection:
          - name: psc-cosmos
            subresourceNames: [Sql]
            isManualConnection: false
            privateConnectionResourceIdSelector: { matchControllerRef: true }
  - name: pushKeyToKV
    base:
      apiVersion: keyvault.azure.upbound.io/v1beta1
      kind: Secret
    patches:
    - fromFieldPath: spec.parameters.serviceName
      toFieldPath: metadata.name
      transforms: [ { type: string, string: { fmt: "%s-cosmos-conn" } } ]
```

## 4.4 XRD #3 — Azure DNS (Zone + Records)

```yaml
apiVersion: apiextensions.crossplane.io/v1
kind: CompositeResourceDefinition
metadata:
  name: xdnsrecords.platform.example.com
spec:
  group: platform.example.com
  names: { kind: XDnsRecord, plural: xdnsrecords }
  claimNames: { kind: DnsRecord, plural: dnsrecords }
  versions:
  - name: v1alpha1
    served: true
    referenceable: true
    schema:
      openAPIV3Schema:
        type: object
        properties:
          spec:
            type: object
            properties:
              parameters:
                type: object
                required: [zoneName, recordName, recordType, value, visibility]
                properties:
                  zoneName:    { type: string }                 # e.g. apps.internal.example.com
                  recordName:  { type: string }                 # e.g. payments
                  recordType:  { type: string, enum: [A, CNAME, TXT] }
                  value:       { type: string }
                  ttl:         { type: integer, default: 300 }
                  visibility:  { type: string, enum: [public, private] }
---
apiVersion: apiextensions.crossplane.io/v1
kind: Composition
metadata:
  name: dns.azure.platform.example.com
spec:
  compositeTypeRef:
    apiVersion: platform.example.com/v1alpha1
    kind: XDnsRecord
  resources:
  - name: aRecord
    base:
      apiVersion: network.azure.upbound.io/v1beta1
      kind: ARecord
      spec:
        forProvider:
          ttl: 300
          zoneNameSelector: { matchLabels: { dns-zone: "platform" } }
          resourceGroupNameSelector: { matchLabels: { role: dns-rg } }
    patches:
    - fromFieldPath: spec.parameters.recordName
      toFieldPath: spec.forProvider.name
    - fromFieldPath: spec.parameters.value
      toFieldPath: spec.forProvider.records[0]
    - fromFieldPath: spec.parameters.ttl
      toFieldPath: spec.forProvider.ttl
    policy:
      resolution: Required
    conditions:
    - { type: equals, fromFieldPath: spec.parameters.recordType, value: A }
  - name: cnameRecord
    base:
      apiVersion: network.azure.upbound.io/v1beta1
      kind: CNAMERecord
      spec:
        forProvider:
          ttl: 300
          zoneNameSelector: { matchLabels: { dns-zone: "platform" } }
          resourceGroupNameSelector: { matchLabels: { role: dns-rg } }
    patches:
    - fromFieldPath: spec.parameters.recordName
      toFieldPath: spec.forProvider.name
    - fromFieldPath: spec.parameters.value
      toFieldPath: spec.forProvider.record
    conditions:
    - { type: equals, fromFieldPath: spec.parameters.recordType, value: CNAME }
```

For *private* zones the composition selects `PrivateDnsARecord`/`PrivateDnsCNAMERecord` from `privatedns.azure.upbound.io`. Visibility = `private` triggers selector switches via composition patches.

## 4.5 XRD #4 — Service Bus (Namespace + Queues + Topics + SAS)

```yaml
apiVersion: apiextensions.crossplane.io/v1
kind: CompositeResourceDefinition
metadata:
  name: xservicebusnamespaces.platform.example.com
spec:
  group: platform.example.com
  names: { kind: XServiceBus, plural: xservicebusnamespaces }
  claimNames: { kind: ServiceBus, plural: servicebusnamespaces }
  versions:
  - name: v1alpha1
    served: true
    referenceable: true
    schema:
      openAPIV3Schema:
        type: object
        properties:
          spec:
            type: object
            properties:
              parameters:
                type: object
                required: [serviceName, environment, sloClass]
                properties:
                  serviceName: { type: string }
                  environment: { type: string, enum: [dev, staging, prod] }
                  sloClass:    { type: string, enum: [bronze, silver, gold] }
                  queues:
                    type: array
                    items:
                      type: object
                      required: [name]
                      properties:
                        name:                 { type: string }
                        maxDeliveryCount:     { type: integer, default: 5 }
                        deadLetteringOnExpiry:{ type: boolean, default: true }
                        lockDuration:         { type: string, default: PT1M }
                  topics:
                    type: array
                    items:
                      type: object
                      properties:
                        name:          { type: string }
                        subscriptions:
                          type: array
                          items: { type: object, properties: { name: { type: string } } }
---
apiVersion: apiextensions.crossplane.io/v1
kind: Composition
metadata:
  name: servicebus.azure.platform.example.com
spec:
  compositeTypeRef:
    apiVersion: platform.example.com/v1alpha1
    kind: XServiceBus
  resources:
  - name: namespace
    base:
      apiVersion: servicebus.azure.upbound.io/v1beta1
      kind: Namespace
      spec:
        forProvider:
          sku: Premium                     # patched by sloClass
          publicNetworkAccessEnabled: false
          minimumTlsVersion: "1.2"
          location: westeurope
    patches:
    - fromFieldPath: spec.parameters.sloClass
      toFieldPath: spec.forProvider.sku
      transforms:
      - type: map
        map: { bronze: Basic, silver: Standard, gold: Premium }
    - fromFieldPath: spec.parameters.serviceName
      toFieldPath: metadata.name
      transforms: [ { type: string, string: { fmt: "sb-%s" } } ]
  - name: sasPolicySend
    base:
      apiVersion: servicebus.azure.upbound.io/v1beta1
      kind: NamespaceAuthorizationRule
      spec:
        forProvider:
          send: true
          listen: false
          manage: false
          namespaceIdSelector: { matchControllerRef: true }
    patches:
    - fromFieldPath: spec.parameters.serviceName
      toFieldPath: metadata.name
      transforms: [ { type: string, string: { fmt: "%s-send" } } ]
  - name: sasPolicyListen
    base:
      apiVersion: servicebus.azure.upbound.io/v1beta1
      kind: NamespaceAuthorizationRule
      spec:
        forProvider:
          send: false
          listen: true
          manage: false
          namespaceIdSelector: { matchControllerRef: true }
    patches:
    - fromFieldPath: spec.parameters.serviceName
      toFieldPath: metadata.name
      transforms: [ { type: string, string: { fmt: "%s-listen" } } ]
  - name: privateEndpoint
    base:
      apiVersion: network.azure.upbound.io/v1beta1
      kind: PrivateEndpoint
      spec:
        forProvider:
          subnetIdSelector: { matchLabels: { role: pe-subnet } }
          privateServiceConnection:
          - name: psc-sb
            subresourceNames: [namespace]
            isManualConnection: false
            privateConnectionResourceIdSelector: { matchControllerRef: true }
  - name: pushConnStringToKV
    base:
      apiVersion: keyvault.azure.upbound.io/v1beta1
      kind: Secret
    patches:
    - fromFieldPath: spec.parameters.serviceName
      toFieldPath: metadata.name
      transforms: [ { type: string, string: { fmt: "%s-sb-listen-conn" } } ]
```

Queues and topics are generated by **functions-go-templating** or **functions-patch-and-transform** loops, so the array shape in the claim drives N child Crossplane resources. (Composition Functions in Crossplane v1.14+ make the array → resource explosion trivial — recommended over hand-rolled go-templating.)

## 4.6 Reconciliation, Drift, and Rate-Limit Resilience

**Drift detection.** Crossplane's runtime polls each managed resource against Azure ARM at `--poll-interval` (default 1 minute). If the live state diverges from `spec.forProvider`, Crossplane re-issues the underlying ARM call. There is **no time-based drift confirmation** — divergence is corrected the first poll after detection, unless `management policies` are set otherwise.

To **opt-out** of drift correction for an attribute users sometimes change out-of-band:

```yaml
spec:
  managementPolicies: ["Observe", "Create", "Update"]   # excludes "LateInitialize" + "Delete"
  initProvider:                                          # only set at creation, not enforced
    tags:
      cost-center: "PE-001"
```

**Reconciliation loop tuning.**

```yaml
# Helm values for provider-upjet-azure
controllerConfig:
  args:
    - --poll-interval=2m              # default 1m; relaxed for cost
    - --max-reconcile-rate=10         # workers per kind
    - --provider-ttl=24h
    - --terraform-version=1.5.7       # pin Upjet's underlying Terraform
resources:
  requests: { cpu: 500m, memory: 2Gi }
  limits:   { memory: 4Gi }
```

**Azure ARM rate-limit handling.** Crossplane (via Upjet) automatically retries on HTTP 429 with the `Retry-After` header. To stay below ARM read limits (12,000 reads/hr/subscription) at scale, we shard provider configs by region:

```yaml
apiVersion: azure.upbound.io/v1beta1
kind: ProviderConfig
metadata:
  name: azure-westeurope
spec:
  credentials:
    source: InjectedIdentity        # AKS Workload Identity
  subscriptionID: 11111111-1111-...
---
apiVersion: azure.upbound.io/v1beta1
kind: ProviderConfig
metadata:
  name: azure-northeurope
spec:
  credentials: { source: InjectedIdentity }
  subscriptionID: 22222222-2222-...
```

XRCs select the per-region ProviderConfig in their claim spec, so each region's reconciler hits a different ARM quota bucket. For transient Azure outages, Crossplane's `LastReconcileTime` + `Synced=False` condition shows up in Prometheus (`crossplane_resource_unready_total`); alerts fire after a 15-minute threshold to avoid noise on short blips. Crossplane resumes automatically once Azure recovers — no operator action required.

**Atomic composition.** A failure during composition (e.g., SQL succeeds but Service Bus fails) leaves the XR in `Ready=False` but does **not** roll back. The application's ArgoCD Application stays in `Progressing` and the operator's runbook is to inspect `kubectl describe xr ...` and decide between retry, delete, or partial accept. This is intentional — automatic rollback of cloud resources is surprisingly often *less* safe than leaving a half-built environment for an operator to inspect.

---

# 5. ZERO-TRUST SECURITY — AZURE KEY VAULT & EXTERNAL SECRETS OPERATOR

## 5.1 End-to-End Secret Lifecycle

```
   ┌──────────────┐   provisions    ┌──────────────────────┐  reads conn-string
   │ Crossplane   │ ──────────────► │  Azure SQL / Cosmos  │  ◄──────────────┐
   │ (in mgmt)    │                 │  / Service Bus       │                 │
   └──────────────┘                 └──────────────────────┘                 │
          │                                                                  │
          │ writes connection JSON                                           │ federated
          ▼                                                                  │ MSAL token
   ┌──────────────────────────────────────────────────────┐                  │
   │  Azure Key Vault (private endpoint, RBAC, soft-delete│ ◄────────────────┘
   │  + purge-protection on)                              │      from workload pod
   └──────────────────────────────────────────────────────┘
          │                                                  ┌───────────────────────┐
          │ polled by ESO every 1 min                        │ Reloader (StakaterIO) │
          ▼                                                  │  watches Secret obj   │
   ┌──────────────────────────────────────┐                  └──────────┬────────────┘
   │ External Secrets Operator (in each   │                             │ on hash change
   │ workload cluster, Workload Identity) │                             ▼
   │  ExternalSecret CR → Secret in NS    │ ──────────────► ┌─────────────────────────┐
   └──────────────────────────────────────┘                 │ App Deployment rollout  │
                                                            └─────────────────────────┘
```

Crossplane's Compositions (§4) emit connection metadata into AKV as `keyvault.azure.upbound.io/v1beta1 Secret` resources. AKV is the single source of secret truth; **no secret ever lives in Git, no secret is generated in a CI pipeline, no static credential exists in any cluster.**

## 5.2 Authentication — Workload Identity Federation (no client secrets)

ESO authenticates to AKV using an Azure-managed identity (UAMI) federated to a Kubernetes ServiceAccount via Workload Identity. This eliminates *all* long-lived credentials.

Setup (one-time per workload cluster, performed by Crossplane via a ProviderConfig XR + an `azure-identity` XRC):

```yaml
# UAMI for ESO, federated to the cluster's serviceaccount
apiVersion: managedidentity.azure.upbound.io/v1beta1
kind: UserAssignedIdentity
metadata:
  name: uami-eso-prod-we
spec:
  forProvider:
    location: westeurope
    resourceGroupNameSelector: { matchLabels: { role: identity-rg } }
---
apiVersion: managedidentity.azure.upbound.io/v1beta1
kind: FederatedIdentityCredential
metadata:
  name: fic-eso-prod-we
spec:
  forProvider:
    parentIdRef: { name: uami-eso-prod-we }
    audience:    [ "api://AzureADTokenExchange" ]
    issuer:      "https://westeurope.oic.prod-aks.azure.com/<TENANT_ID>/<CLUSTER_OIDC_ID>/"
    subject:     "system:serviceaccount:external-secrets:eso-sa"
---
# Grant the UAMI Key Vault Secrets User on the platform KV
apiVersion: authorization.azure.upbound.io/v1beta1
kind: RoleAssignment
metadata:
  name: ra-eso-kv-reader
spec:
  forProvider:
    principalIdSelector: { matchControllerRef: true }   # uami-eso-prod-we
    roleDefinitionIdLiteral: "/providers/Microsoft.Authorization/roleDefinitions/4633458b-17de-408a-b874-0445c86b69e6"  # Key Vault Secrets User
    scopeSelector: { matchLabels: { role: platform-kv } }
```

## 5.3 ESO ClusterSecretStore (Workload Identity)

```yaml
apiVersion: external-secrets.io/v1beta1
kind: ClusterSecretStore
metadata:
  name: azure-keyvault
spec:
  provider:
    azurekv:
      authType: WorkloadIdentity
      vaultUrl: https://kv-platform-prod.vault.azure.net
      serviceAccountRef:
        name: eso-sa
        namespace: external-secrets
      environmentType: PublicCloud
---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: eso-sa
  namespace: external-secrets
  annotations:
    azure.workload.identity/client-id: "<UAMI_CLIENT_ID_FROM_CROSSPLANE_STATUS>"
    azure.workload.identity/tenant-id: "<TENANT_ID>"
  labels:
    azure.workload.identity/use: "true"
```

The ESO deployment must include the workload-identity pod label and projected token volume (the operator's Helm chart sets these when `serviceAccount.create=false` and the SA is annotated as above).

## 5.4 ExternalSecret — Fetch a SQL Connection into a Workload Namespace

```yaml
apiVersion: external-secrets.io/v1beta1
kind: ExternalSecret
metadata:
  name: payments-sql-conn
  namespace: payments
spec:
  refreshInterval: 1m
  secretStoreRef:
    kind: ClusterSecretStore
    name: azure-keyvault
  target:
    name: payments-sql-conn           # Kubernetes Secret created in 'payments' namespace
    creationPolicy: Owner
    template:
      engineVersion: v2
      type: Opaque
      metadata:
        annotations:
          reloader.stakater.com/match: "true"
      data:
        SQL_SERVER:   "{{ .conn | fromJson | dig "server" "" }}"
        SQL_DATABASE: "{{ .conn | fromJson | dig "database" "" }}"
        SQL_AUTHMODE: "{{ .conn | fromJson | dig "authMode" "" }}"
  data:
  - secretKey: conn
    remoteRef:
      key: payments-sql-conn          # AKV secret name written by Crossplane
      version: latest                 # always pick the active version
```

A parallel `ExternalSecret` for Cosmos uses `key: payments-cosmos-conn`, and one for Service Bus uses `key: payments-sb-listen-conn`. The app's `Deployment` mounts the Kubernetes Secret via `envFrom: { secretRef: { name: payments-sql-conn } }` and is **never** aware that AKV exists.

## 5.5 Secret Rotation Strategy — End-to-End

1. **Rotation in AKV** is initiated by either (a) Crossplane (every 90 days, via a CronJob that bumps a `version` label on the connection KV-Secret, which re-pulls SQL keys), or (b) an Azure Event Grid subscription on `Microsoft.KeyVault.SecretNewVersionCreated` for keys outside Crossplane's control (e.g., third-party API keys uploaded by humans).
2. **ESO polls** every `refreshInterval` (1 min for production). On detecting a new version, it rewrites the Kubernetes Secret.
3. **Reloader** (Stakater) watches the Secret. Because the Secret has `reloader.stakater.com/match: "true"`, Reloader detects the hash change and triggers a rolling restart of any Deployment / StatefulSet that mounts it.
4. **App startup** reads the new env vars (or re-mounts the projected file) — picks up the new secret with zero developer involvement.
5. **Validation gate:** the app's readinessProbe must include an actual call to the downstream system (a `SELECT 1` against SQL, a `peek-lock` against Service Bus). If readiness fails, the rollout halts — protecting against a botched rotation.

End-to-end MTTR for an automatic rotation: about 90 seconds (1 min ESO poll + 30s rolling restart).

## 5.6 PlantUML — Secret Lifecycle Flow

```plantuml
@startuml
title Zero-Trust Secret Lifecycle
skinparam ParticipantBackgroundColor #FFFFFF
skinparam ParticipantBorderColor #2B579A
skinparam SequenceLifeLineBorderColor #2B579A
skinparam defaultFontName Helvetica

actor "Platform Engineer" as PE
participant "Crossplane\n(mgmt cluster)" as XP
database  "Azure SQL"  as SQL
participant "Azure ARM"  as ARM
database  "Azure Key Vault" as AKV
participant "ESO\n(workload cluster)" as ESO
participant "K8s API"   as K8S
participant "Reloader" as REL
participant "App Pod"   as POD

== Provisioning ==
PE -> XP : kubectl apply XRC SQLDatabase
XP -> ARM : Create SQL server + DB (private)
ARM -> SQL : provisioned
XP -> AKV : write `payments-sql-conn` (JSON)

== Consumption ==
ESO -> AKV : GET secret (Workload Identity token)
AKV -> ESO : payments-sql-conn v1
ESO -> K8S : create/update Secret `payments-sql-conn`
K8S -> POD : mounted via envFrom

== Rotation ==
note over AKV: Cron in Crossplane bumps key version every 90d
AKV -> AKV : new version v2 (auto)
ESO -> AKV : poll (every 1m)
AKV -> ESO : v2
ESO -> K8S : update Secret (new hash)
REL -> K8S : detect hash change\n→ rollout restart Deployment
K8S -> POD : new pod starts
POD -> SQL : connect with v2 creds
POD -> K8S : readiness OK
note over K8S: Old pod terminated, rollout complete
@enduml
```

---

# 6. ARGOCD GITOPS ENGINE CONFIGURATION

## 6.1 Hub-and-Spoke Topology

A single **ArgoCD instance** runs in the management cluster as the hub. Workload clusters are registered as remote targets using Azure-AD-federated short-lived tokens (no `kubeconfig` files). ArgoCD's HA chart deploys:

- 3 application-controllers (sharded by cluster)
- 2 repo-servers
- 3 redis-ha replicas
- 2 servers behind an internal LB

## 6.2 ApplicationSet — Multi-Tenant, Multi-Cluster

The **App-of-Apps** is replaced by an **ApplicationSet with Matrix generators**: one axis is `clusters`, the other is `services` (discovered via a Git generator scanning `apps/*/overlays/*`).

```yaml
apiVersion: argoproj.io/v1alpha1
kind: ApplicationSet
metadata:
  name: workloads
  namespace: argocd
spec:
  goTemplate: true
  generators:
  - matrix:
      generators:
      - clusters:
          selector:
            matchLabels:
              env: "dev"
      - git:
          repoURL: git@bitbucket.org:platform-prod/platform-gitops.git
          revision: main
          directories:
          - path: apps/*/overlays/dev
  - matrix:
      generators:
      - clusters:
          selector:
            matchLabels:
              env: "staging"
      - git:
          repoURL: git@bitbucket.org:platform-prod/platform-gitops.git
          revision: main
          directories:
          - path: apps/*/overlays/staging
  - matrix:
      generators:
      - clusters:
          selector:
            matchLabels:
              env: "prod"
      - git:
          repoURL: git@bitbucket.org:platform-prod/platform-gitops.git
          revision: main
          directories:
          - path: apps/*/overlays/prod
  template:
    metadata:
      name: '{{ index .path.segments 1 }}-{{ .name }}'    # e.g., payments-dev-aks-we
      labels:
        owner: '{{ index .path.segments 1 }}'
        env:   '{{ .metadata.labels.env }}'
    spec:
      project: workloads
      source:
        repoURL: git@bitbucket.org:platform-prod/platform-gitops.git
        targetRevision: main
        path: '{{ .path.path }}'
      destination:
        name: '{{ .name }}'                               # registered cluster name
        namespace: '{{ index .path.segments 1 }}'
      syncPolicy:
        automated:
          prune: true
          selfHeal: true
          allowEmpty: false
        syncOptions:
        - CreateNamespace=true
        - PrunePropagationPolicy=foreground
        - ServerSideApply=true
        - ApplyOutOfSyncOnly=true
        retry:
          limit: 5
          backoff:
            duration: 30s
            factor: 2
            maxDuration: 5m
      revisionHistoryLimit: 20      # rollback to last 20 syncs
```

## 6.3 Sync Waves — Ordering Crossplane → ESO → Workload

ArgoCD's **sync-wave annotation** orders resources within a single Application. The platform convention:

| Wave | Resource Type | Reason |
|---|---|---|
| `-1` | Namespaces, RBAC, NetworkPolicies | Must exist before anything is scheduled |
| `0` | Crossplane Composite Resource Claims (SQL, Cosmos, Service Bus, DNS) | Provision cloud — slow |
| `1` | ExternalSecret resources | Need AKV populated by wave-0 Crossplane outputs |
| `2` | ConfigMaps, Secrets (generated), ServiceAccounts | Glue |
| `3` | Deployments / StatefulSets / Services | Need waves 0–2 ready |
| `4` | HorizontalPodAutoscalers, PodDisruptionBudgets | Post-startup tuning |
| `5` | Ingress / VirtualServices | Expose only when pods are Ready |

Example wave annotations on the app's manifests:

```yaml
# apps/payments/base/xrc-sql.yaml
apiVersion: platform.example.com/v1alpha1
kind: SQLDatabase
metadata:
  name: payments
  annotations:
    argocd.argoproj.io/sync-wave: "0"
spec:
  parameters: { serviceName: payments, environment: prod, sloClass: gold, entraAdminGroupObjectId: ... }
---
# apps/payments/base/external-secret-sql.yaml
apiVersion: external-secrets.io/v1beta1
kind: ExternalSecret
metadata:
  name: payments-sql-conn
  annotations:
    argocd.argoproj.io/sync-wave: "1"
spec: { ... }
---
# apps/payments/base/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: payments
  annotations:
    argocd.argoproj.io/sync-wave: "3"
spec: { ... }
```

**Race-condition avoidance:** Crossplane XR readiness is gated by the underlying Azure provisioning. The XR's status condition `Ready=True` only flips after the SQL server, database, and Key Vault secret are all live. ArgoCD's wave-0 sync waits for this condition (via `health.lua` custom health checks registered in `argocd-cm`):

```yaml
# argocd-cm
data:
  resource.customizations.health.platform.example.com_SQLDatabase: |
    hs = {}
    if obj.status ~= nil and obj.status.conditions ~= nil then
      for i, condition in ipairs(obj.status.conditions) do
        if condition.type == "Ready" and condition.status == "True" then
          hs.status = "Healthy"
          hs.message = condition.message
          return hs
        end
      end
    end
    hs.status = "Progressing"
    hs.message = "Waiting for SQLDatabase to become Ready"
    return hs
```

Only when wave-0 is Healthy does ArgoCD start wave-1.

## 6.4 Self-Healing & Automated Rollback

`syncPolicy.automated.selfHeal: true` means **any drift from Git is reverted** in under one reconciliation cycle (default ~3 min, tuned to 30s via `timeout.reconciliation` in `argocd-cm`).

**Automated rollback** for a failed deployment uses ArgoCD's PostSync hooks + the `revisionHistoryLimit`:

```yaml
# apps/payments/base/post-sync-healthcheck.yaml
apiVersion: batch/v1
kind: Job
metadata:
  name: payments-postsync-healthcheck
  annotations:
    argocd.argoproj.io/hook: PostSync
    argocd.argoproj.io/hook-delete-policy: HookSucceeded
spec:
  ttlSecondsAfterFinished: 60
  template:
    spec:
      restartPolicy: Never
      containers:
      - name: healthcheck
        image: curlimages/curl:8.6.0
        command:
        - sh
        - -c
        - |
          set -e
          for i in $(seq 1 20); do
            if curl -fsS http://payments.payments.svc:8080/health/deep; then exit 0; fi
            sleep 6
          done
          echo "Healthcheck failed after 2 min"
          exit 1
```

If the Job fails, ArgoCD marks the sync `Degraded`. Combined with an Argo Rollouts (or Flagger) progressive-delivery strategy in front of the Deployment, the failed canary is automatically scaled down and the previous ReplicaSet is restored. The `notifications` webhook to `argocd-jira-bridge` (§2.3) opens a Jira incident.

For services that don't use Argo Rollouts, manual rollback is one command:
```
argocd app rollback payments-prod-aks-we 7   # the previous successful sync
```

## 6.5 PlantUML — ArgoCD Sync Wave Workflow

```plantuml
@startuml
title ArgoCD Sync Waves — Race-Free Cross-Operator Coordination
skinparam defaultFontName Helvetica
skinparam ActivityBackgroundColor #FFF4E8
skinparam ActivityBorderColor #E67E22

start
:Git commit detected by ArgoCD repo-server;
:Application enters Syncing state;

partition "Wave -1: Foundations" {
  :Apply Namespace, RBAC, NetworkPolicy;
  :Wait Healthy;
}

partition "Wave 0: Crossplane XRCs" {
  :Apply SQLDatabase, CosmosAccount,\nServiceBus, DnsRecord claims;
  while (XR conditions Ready=True?) is (no)
    :Poll every 30s, max 30 min;
  endwhile (yes)
  note right
    Azure provisioning happens here;
    Crossplane writes connection JSON to AKV
  end note
}

partition "Wave 1: ESO ExternalSecrets" {
  :Apply ExternalSecret resources;
  :ESO fetches AKV secrets;
  :K8s Secrets created in namespace;
}

partition "Wave 2: Glue (CMs, SAs)" {
  :Apply ConfigMaps, ServiceAccounts;
}

partition "Wave 3: Workloads" {
  :Apply Deployment / StatefulSet;
  :Pods mount Secrets (envFrom);
  :Pods become Ready;
}

partition "Wave 4: Autoscaling, PDB" {
  :Apply HPA, PDB;
}

partition "Wave 5: Ingress" {
  :Apply Ingress / VirtualService;
}

:PostSync Job: deep healthcheck;
if (Healthcheck passes?) then (yes)
  :Application Healthy;
  :Notify Jira → DEPLOYED;
else (no)
  :Mark Degraded;
  :Argo Rollouts rolls back canary;
  :Notify Jira → INCIDENT;
endif
stop
@enduml
```

---

# 7. DAY-2 OPERATIONS, OBSERVABILITY & RESILIENCE RUNBOOKS

## 7.1 Observability Stack

| Signal | Tool | Source | What to alert on |
|---|---|---|---|
| Metrics | Prometheus (kube-prometheus-stack) + Azure Managed Prometheus | All clusters | ArgoCD `argocd_app_info{sync_status!="Synced"}` > 10 min; Crossplane `crossplane_resource_unready_total` > 0 for 15 min; ESO `externalsecret_status_condition{status="False"}`; Jenkins `jenkins_node_offline_value`; AKS `node_not_ready_total` |
| Logs | Loki (or Azure Log Analytics) | All clusters via Promtail/AMA-agent | Error spikes; ArgoCD repo-server rate-limit errors; Crossplane provider 429s |
| Traces | Tempo (or Azure App Insights) + OTel collector DaemonSet | App workloads | Trace cardinality on slow endpoints; cross-service latency tail |
| Dashboards | Grafana | Both Prometheus & Loki | One dashboard per concern: "Platform Loop Health", "Per-Service Deploy Status", "Crossplane Drift", "Secret Freshness" |

Key alert examples:

```yaml
- alert: ArgoCDAppOutOfSync
  expr: argocd_app_info{sync_status="OutOfSync"} == 1
  for: 10m
  labels: { severity: warning }
  annotations:
    summary: "ArgoCD app {{ $labels.name }} is out of sync"

- alert: CrossplaneXRNotReady
  expr: sum by(name,kind,namespace) (kube_customresource_crossplane_io_status_condition{condition="Ready",status="False"}) > 0
  for: 15m
  labels: { severity: critical }

- alert: ESOSecretStale
  expr: time() - external_secrets_sync_calls_last_seconds > 600
  for: 5m
  labels: { severity: warning }
  annotations:
    summary: "ESO has not synced {{ $labels.name }} in 10 min"

- alert: ImageNotCosignSigned
  expr: increase(gatekeeper_violations_total{kind="K8sRequiredCosignSignature"}[5m]) > 0
  for: 0m
  labels: { severity: critical }
```

## 7.2 The Three Platform-Loop SLOs

| SLO | Target | Measurement |
|---|---|---|
| **Time-to-deploy** — commit on main → app Healthy on dev | p95 ≤ 10 min | Jenkins build duration + ArgoCD sync duration |
| **Drift-correction-MTTR** — manual change → reverted | p95 ≤ 5 min | ArgoCD reconcile + revert latency |
| **Secret freshness** — AKV rotation → app restart | p95 ≤ 90 s | ESO poll interval + Reloader delay + pod start |

## 7.3 Disaster Recovery — Total Loss of the ArgoCD Control Plane Cluster

**Scope.** The management AKS cluster `mgmt-we` has been destroyed (region-wide Azure incident, accidental deletion, or compromise). Workload clusters in `prod-we` and `prod-ne` are still running and serving traffic.

**Pre-conditions met before the incident:**
1. The Git repo `platform-gitops` is the source of truth and is replicated (Bitbucket Cloud → GitHub Enterprise mirror via scheduled job).
2. Velero is taking 6-hourly snapshots of the management cluster's etcd + PVs to a geo-redundant storage account.
3. The ArgoCD bootstrap manifests (App-of-Apps, ApplicationSet, Project, AppProject definitions, cluster credentials secret templates) are themselves in Git under `bootstrap/`.
4. A Crossplane "control-plane-claim" XRC exists in `bootstrap/` that, when applied, provisions a new AKS management cluster.
5. The Workload Identity federation OIDC URLs for each workload cluster are stored in Git (they are not secrets).

**Recovery runbook:**

```
STEP 1 — DECLARE INCIDENT (T+0)
  - Page on-call platform engineer
  - Open Jira INCIDENT, set severity SEV1
  - Inform stakeholders: "Control plane lost; workloads unaffected; drift correction paused"

STEP 2 — VALIDATE WORKLOAD HEALTH (T+5min)
  - Confirm via direct kubectl to workload clusters (using break-glass admin creds in AKV):
      kubectl --context prod-we get pods -A
  - Confirm Front Door routing still serving customer traffic
  - Identify any in-flight Crossplane reconciliations that may be stuck

STEP 3 — PROVISION NEW MGMT CLUSTER (T+15min)
  Option A (fastest, if mgmt-ne is healthy): promote mgmt-ne
      - Update Front Door / external DNS to point operators at mgmt-ne ArgoCD UI
      - Update ArgoCD on mgmt-ne to reconcile actively (it was in standby mode)
        kubectl --context mgmt-ne -n argocd patch deployment argocd-application-controller \
          -p '{"spec":{"replicas":3}}'

  Option B (full rebuild): Crossplane control-plane-claim from a "seed" mgmt cluster
      - Use the seed cluster (a tiny single-node AKS in a third region maintained for this purpose)
      - kubectl --context seed apply -f bootstrap/control-plane-claim.yaml
      - Wait for new mgmt cluster (T+15min for AKS provisioning)

STEP 4 — RESTORE ARGOCD (T+25min)
  - On the new mgmt cluster:
      helm install argocd argo/argo-cd -n argocd --create-namespace -f bootstrap/argocd-values.yaml
      kubectl apply -f bootstrap/argocd-bootstrap-applicationset.yaml
  - ArgoCD reads platform-gitops, syncs itself, then syncs every other Application from Git.
  - No state-restore is needed: the Apps' desired state is in Git; the live state on workload
    clusters is preserved; ArgoCD will reconcile diffs.

STEP 5 — RE-REGISTER WORKLOAD CLUSTERS (T+30min)
  - For each workload cluster, apply the cluster secret manifest (this contains the OIDC
    federation info but no static credentials):
      kubectl apply -f bootstrap/clusters/prod-we-secret.yaml
      kubectl apply -f bootstrap/clusters/prod-ne-secret.yaml
      kubectl apply -f bootstrap/clusters/staging-secret.yaml
      kubectl apply -f bootstrap/clusters/dev-secret.yaml

STEP 6 — RECONCILE & VALIDATE (T+40min)
  - Watch ArgoCD UI for all Applications to reach Healthy + Synced
  - Verify Crossplane XRs are Ready (they should be — nothing was deleted in Azure)
  - Verify ESO is reconciling (Workload Identity federation is unaffected, since
    UAMI lives in Azure, not in any cluster)
  - Run smoke tests:
      argocd app sync-status --refresh
      kubectl --context prod-we -n payments get pods,svc,externalsecret,sqldatabase

STEP 7 — POST-INCIDENT (T+60min)
  - Verify Jenkins is reachable (it shares mgmt cluster lifecycle — see Jenkins DR addendum)
  - Trigger one canary deploy through CI to confirm end-to-end loop
  - Close Jira incident; schedule blameless postmortem within 5 business days
```

**Total expected recovery time:** 30-45 minutes (Option A) / 45-60 minutes (Option B). **Workload-impact during this window: zero** — by design.

**Jenkins DR addendum.** Because Jenkins runs in the mgmt cluster, it goes down with the cluster. Recovery is via the same Velero snapshot for `$JENKINS_HOME` PVC — restoring that volume to the new cluster brings back the job history. Pipelines in flight are lost; the seed job re-runs are idempotent (they detect existing repos / branches and skip).

## 7.4 PlantUML — DR Recovery Flow

```plantuml
@startuml
title DR Runbook — Management Plane Loss Recovery
skinparam defaultFontName Helvetica
skinparam ActivityBackgroundColor #FCE8E6
skinparam ActivityBorderColor #C62828

start
:T+0 — Page alerts fire\n(mgmt-we API unreachable);
:Open Jira SEV1 incident;

:T+5 — Validate workload health\n(direct kubectl to prod-we/ne);
if (Workloads serving?) then (yes)
  :Confirm: drift paused, traffic unaffected;
else (no)
  :Escalate — workload incident\n(separate runbook);
  stop
endif

:T+15 — Decide rebuild path;
if (mgmt-ne healthy?) then (yes)
  :Promote mgmt-ne\n(scale controllers to 3);
else (no)
  :Apply control-plane-claim XRC\nfrom seed cluster;
  :Wait for new AKS (~15m);
endif

:T+25 — Install ArgoCD\nfrom bootstrap manifests;
:Apply bootstrap ApplicationSet;
:ArgoCD self-syncs from Git;

:T+30 — Re-register clusters\n(apply Workload-Identity-only secrets);

:T+40 — Verify reconciliation;
fork
  :ArgoCD apps → Healthy;
fork again
  :Crossplane XRs → Ready;
fork again
  :ESO secrets → fresh;
end fork

:Run smoke tests\n(canary deploy);
if (Smoke OK?) then (yes)
  :T+60 — Close incident\nSchedule postmortem;
  stop
else (no)
  :Roll back to last known good\n(argocd app rollback);
  :Escalate to platform-lead;
  stop
endif
@enduml
```

---

## Appendix A — Bill of Materials

| Component | Version (tested) | License |
|---|---|---|
| AKS | 1.29+ | Azure |
| ArgoCD | v2.11+ HA | Apache-2.0 |
| Crossplane | v1.16+ | Apache-2.0 |
| provider-upjet-azure | v1.4+ | Apache-2.0 |
| External Secrets Operator | v0.10+ | Apache-2.0 |
| Reloader | v1.0+ | Apache-2.0 |
| Jenkins | LTS 2.452+ | MIT |
| kubernetes-plugin | v4220+ | MIT |
| Cosign | v2.2+ | Apache-2.0 |
| Trivy | v0.50+ | Apache-2.0 |
| Velero | v1.13+ | Apache-2.0 |
| kube-prometheus-stack | v58+ | Apache-2.0 |

## Appendix B — Folder Layout (platform-gitops repo)

```
platform-gitops/
├── bootstrap/                       # ArgoCD bootstrap + cluster definitions
│   ├── argocd-values.yaml
│   ├── argocd-bootstrap-applicationset.yaml
│   ├── control-plane-claim.yaml     # Crossplane XRC for the mgmt cluster itself
│   └── clusters/
│       ├── dev-secret.yaml
│       ├── staging-secret.yaml
│       ├── prod-we-secret.yaml
│       └── prod-ne-secret.yaml
├── platform/                        # platform-wide infra (not per-app)
│   ├── crossplane-providers/
│   ├── eso-clustersecretstore.yaml
│   ├── argocd-projects.yaml
│   └── network-policies/
├── apps/                            # one folder per service (auto-generated)
│   └── payments/
│       ├── base/
│       │   ├── kustomization.yaml
│       │   ├── deployment.yaml
│       │   ├── service.yaml
│       │   ├── ingress.yaml
│       │   ├── xrc-sql.yaml
│       │   ├── xrc-cosmos.yaml
│       │   ├── xrc-sb.yaml
│       │   ├── external-secret-sql.yaml
│       │   ├── external-secret-cosmos.yaml
│       │   └── external-secret-sb.yaml
│       └── overlays/
│           ├── dev/        { kustomization.yaml + replicas/image patches }
│           ├── staging/    { ... }
│           └── prod/       { ... }
└── templates/                       # used by the Jenkins seed job
    ├── node-service/                # Cookiecutter
    ├── go-service/
    ├── jvm-service/
    └── python-service/
```

---

*End of blueprint. Diagram delivered separately: `IDP-C4-Container.drawio`.*
