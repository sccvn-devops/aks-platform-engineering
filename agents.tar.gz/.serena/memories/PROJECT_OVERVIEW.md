# AKS Platform Engineering - Project Overview

## Project Name
**Building a Platform Engineering Environment on Azure Kubernetes Service (AKS)**

## Purpose
Reference architecture & implementation for a platform engineering strategy on Azure using:
- AKS (Azure Kubernetes Service) for container orchestration
- ArgoCD for GitOps deployments
- Crossplane or Cluster API (CAPZ) for infrastructure management
- Backstage as the developer portal

## Key Goals
- Construct adaptable, reliable platform engineering foundation
- Simplify infrastructure/operational complexity for dev teams
- Enable multi-cluster support with environment isolation (dev, staging, prod)
- Implement GitOps principles across infrastructure and applications
- Provide Day 2 operations management

## GitHub Context
- Open source Microsoft sample project
- Uses Contributor License Agreement (CLA)
- Microsoft Open Source Code of Conduct applies

## Versions
- Backstage: 1.32.2
- Node: 18 || 20
- TypeScript: ~5.2.0
- Terraform: v1.8.3+

## Microsoft Products Used
- Azure Resource Manager
- Azure Kubernetes Service (AKS)
- Azure Container Registry
- Azure Storage
- Azure Blob Storage
- Azure Monitor
- Azure Log Analytics
- Azure Virtual Machines
