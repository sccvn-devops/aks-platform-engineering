# AKS Platform Engineering - Onboarding Complete

## Repository Onboarded Successfully ✓

This repository has been fully analyzed and comprehensive memory/cache created for efficient navigation and development.

---

## Memory Files Created

### 1. **PROJECT_OVERVIEW.md**
   - Project name, purpose, and goals
   - Key GitHub details
   - Tool versions and requirements
   - Microsoft products involved

### 2. **ARCHITECTURE.md**
   - GitOps Bridge Pattern overview
   - Control Plane & Workload Cluster architecture
   - Infrastructure provider options (CAPZ/Crossplane)
   - Core addon components
   - TLS/Security setup

### 3. **DIRECTORY_STRUCTURE.md**
   - Complete folder organization
   - Root-level files and documentation
   - Detailed breakdown of: `/terraform/`, `/backstage/`, `/gitops/`, `/docs/`
   - Monorepo structure (Lerna + Yarn)

### 4. **TECHNOLOGIES.md**
   - Complete tech stack
   - Infrastructure & cloud tools
   - Deployment & automation tools
   - Developer portal (Backstage 1.32.2)
   - Backend services & dependencies
   - Development tools & frameworks
   - Database, authentication, observability options

### 5. **BUILD_COMMANDS.md**
   - Prerequisites checklist
   - Backstage setup & development commands
   - Build, testing, and code quality commands
   - Terraform deployment workflows
   - Cluster access procedures
   - GitHub configuration guide
   - Useful workspace operations

### 6. **CODE_CONVENTIONS.md**
   - Monorepo structure patterns
   - TypeScript naming conventions
   - Backstage app patterns
   - GitOps file organization
   - Terraform patterns
   - Configuration patterns
   - Testing approach (Playwright + Jest)
   - Development workflow
   - Dependency management

### 7. **QUICK_REFERENCE.md**
   - Project summary at a glance
   - Key files and their purposes
   - Important variables & configuration
   - Common tasks with commands
   - Key endpoints & access info
   - Testing & QA commands
   - Useful search patterns

### 8. **CODEBASE_INDEX.md**
   - Complete directory tree with descriptions
   - All files explained and categorized
   - Key dependencies & imports
   - Configuration files map
   - Important code entry points
   - Build artifacts
   - Key decision points

---

## Repository Summary

**Project**: Building a Platform Engineering Environment on Azure Kubernetes Service (AKS)

**Type**: Reference architecture + implementation sample

**Core Components**:
- **Infrastructure**: Azure AKS + Terraform (CAPZ or Crossplane)
- **GitOps**: ArgoCD for declarative deployments
- **Developer Portal**: Backstage 1.32.2 (React frontend + Node.js backend)
- **Deployment Model**: Control Plane + Multiple Workload Clusters

**Key Technologies**:
- Kubernetes, Helm, Docker
- GitOps (ArgoCD, Argo Rollouts, Argo Workflows, Argo Events, Kargo)
- Backstage, Azure Entra ID
- Terraform, Lerna, Yarn, TypeScript, React
- Crossplane or Cluster API Provider for Azure

**Code Structure**:
- **Lerna Monorepo** with Yarn workspaces
- **Packages**: app (React), backend (Node.js), examples, template-cluster
- **Plugins**: Custom Backstage extensions
- **Terraform**: Azure infrastructure provisioning
- **GitOps**: ArgoCD manifests for control plane & workload clusters

---

## Quick Start for Development

### To Work on Backstage (Frontend/Backend)
```bash
cd backstage
yarn install
yarn dev          # Runs frontend + backend
```

### To Deploy Infrastructure
```bash
cd terraform
terraform init -upgrade
terraform apply -var gitops_addons_org=https://github.com/<your-fork> --auto-approve
```

### To Access Deployed Services
```bash
# Kubeconfig
export KUBECONFIG=<path>/terraform/kubeconfig

# ArgoCD
kubectl port-forward svc/argocd-server 8080:443 -n argocd
# Get password: kubectl get secret argocd-initial-admin-secret -n argocd --template="{{index .data.password | base64decode}}"

# Backstage
kubectl get svc backstage-backstagechart -n backstage  # Get external IP
```

---

## Key Files to Understand

| Priority | File | Content |
|----------|------|---------|
| **Critical** | `terraform/main.tf` | Infrastructure definition |
| **Critical** | `backstage/package.json` | Monorepo root, workspace config |
| **Critical** | `gitops/bootstrap/control-plane/addons/` | Core infrastructure addons |
| **Important** | `backstage/app-config.yaml` | Backstage runtime config |
| **Important** | `docs/backstage.md` | Backstage setup guide |
| **Important** | `terraform/variables.tf` | Configuration options |
| **Reference** | `README.md` | Project overview |
| **Reference** | `CONTRIBUTING.md` | Contribution guidelines |

---

## Architecture Decision Points

### 1. Infrastructure Provider
- **Default**: CAPZ (Cluster API Provider for Azure)
- **Alternative**: Crossplane
- **Configure**: `terraform/variables.tf` - `infrastructure_provider` variable

### 2. Backstage Features
- **Default**: Enabled (integrated into control plane)
- **Toggle**: `build_backstage` Terraform variable
- **Config**: `backstage/app-config*.yaml`
- **Auth**: Azure Entra ID integration

### 3. Addons
- **Always Enabled**: ArgoCD, Argo Rollouts, Argo Events, Argo Workflows, Kargo
- **Conditional**: Based on infrastructure provider
- **Optional**: Monitoring, policy enforcement, ingress, etc.
- **Configure**: `terraform/variables.tf` - `addons` variable

---

## Common Development Tasks

### Add a New Backstage Plugin
```bash
cd backstage
yarn new              # Follow prompts
yarn dev              # Test locally
```

### Modify Infrastructure Addons
1. Update Helm values in `gitops/environments/default/addons/<addon-name>/`
2. Commit and push
3. ArgoCD auto-syncs to clusters

### Deploy a New Workload Cluster
1. Create definition in `gitops/clusters/capz/` or `gitops/clusters/crossplane/`
2. Use existing templates as reference
3. Commit and push
4. ArgoCD creates the cluster

### Customize Backstage Configuration
1. Edit `backstage/app-config.yaml` (production)
2. Edit `backstage/app-config-local.yaml` (development)
3. Redeploy or restart for changes to take effect

---

## Testing & Quality

### Code Quality Checks
```bash
yarn lint:all              # Lint all packages
yarn prettier:check        # Format check
yarn tsc:full             # Type check
yarn fix                  # Auto-fix issues
```

### Tests
```bash
yarn test:all             # Unit tests with coverage
yarn test:e2e             # E2E tests (Playwright)
```

---

## Important Constraints & Notes

⚠️ **Manual Steps** (To Be Automated):
- Backstage TLS certificate generation (uses openssl.cnf)
- Azure Entra ID admin consent for user syncing

⚠️ **Prerequisites**:
- GitHub PAT required for Backstage features
- Azure CLI, Terraform, kubectl must be installed
- SSH deploy keys only needed for private repos

⚠️ **Configuration**:
- Default K8s version: Latest in region
- Default VM size: Standard_D2s_v3
- Default location: eastus2

---

## Memory Organization

All memory files are stored in `/memories/repo/`:
- Quick reference: **QUICK_REFERENCE.md**
- Implementation guide: **BUILD_COMMANDS.md**
- Code patterns: **CODE_CONVENTIONS.md**
- Complete index: **CODEBASE_INDEX.md**
- Architecture: **ARCHITECTURE.md** + **PROJECT_OVERVIEW.md**
- Structure: **DIRECTORY_STRUCTURE.md**
- Stack: **TECHNOLOGIES.md**

**Access Pattern**: When working on specific tasks:
1. Consult **QUICK_REFERENCE.md** for commands
2. Check **CODE_CONVENTIONS.md** for patterns
3. Reference **CODEBASE_INDEX.md** for file locations
4. Use **BUILD_COMMANDS.md** for detailed setup

---

## Next Steps for Development

1. **Fork the repository** to your GitHub account
2. **Clone your fork** locally
3. **Run Terraform** to provision infrastructure
4. **Access Backstage** and ArgoCD
5. **Develop** new features or customize existing ones
6. **Deploy** changes via GitOps (commit to git)

## Support Resources

- **README.md** - Getting started guide
- **CONTRIBUTING.md** - Contribution workflow
- **docs/backstage.md** - Backstage-specific documentation
- **docs/capz-or-crossplane.md** - Infrastructure comparison
- **docs/Onboard-New-Dev-Team.md** - Team onboarding process

---

## Onboarding Summary

✅ Project structure analyzed
✅ Documentation reviewed
✅ Architecture understood
✅ Key files identified
✅ Configuration options mapped
✅ Build/deployment workflows documented
✅ Code conventions extracted
✅ Complete index created

**Status**: Ready for development and contributions

