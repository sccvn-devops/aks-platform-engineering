# AKS Platform Engineering - Technology Stack

## Infrastructure & Cloud
- **Cloud Provider**: Microsoft Azure
- **Container Orchestration**: AKS (Azure Kubernetes Service)
- **IaC Tool**: Terraform v1.8.3+
- **GitOps**: ArgoCD (chart v7.8.25)
- **Infrastructure Management**: CAPZ (default) or Crossplane
- **Policy Enforcement**: Gatekeeper, Kyverno (optional)
- **Cert Manager**: cert-manager (for CAPZ)

## Deployment & Automation
- **Progressive Delivery**: Argo Rollouts (chart v2.39.5)
- **Workflow Orchestration**: Argo Workflows
- **Event-Driven**: Argo Events
- **Progressive Delivery Orchestrator**: Kargo (chart v1.4.1)
- **Ingress**: NGINX Ingress Controller (optional)
- **Service Mesh**: (Not mentioned - potential addition)

## Developer Portal
- **Framework**: Backstage 1.32.2
- **Frontend**: React with TypeScript
- **Backend**: Node.js
- **Features**:
  - Service Catalog
  - Software Templates
  - TechDocs
  - Plugin ecosystem
  - Azure Entra ID authentication

## Backend Services (Monorepo Packages)
- `@backstage/cli` v0.28.0 - Backstage CLI tooling
- `@backstage/catalog-client` v1.7.1 - Catalog APIs
- TypeScript v5.2
- Node v18 or v20

## Development Tools
- **Package Manager**: Yarn (workspaces)
- **Monorepo Tool**: Lerna v7.3.0
- **TypeScript**: ~5.2.0
- **Testing**: Playwright v1.32.3 (E2E), Jest (unit)
- **Linting**: ESLint
- **Formatting**: Prettier (Spotify config)
- **Build Tool**: backstage-cli repo build

## Database & Authentication
- **Auth**: Azure Entra ID (via Backstage plugin)
- **User Sync**: MS Graph API integration
- **Roles**: Admin roles required for user syncing

## Observability (Optional)
- **Monitoring**: Kube Prometheus Stack (optional)
- **Logging**: Azure Monitor, Log Analytics
- **Metrics**: Prometheus Adapter, Metrics Server

## Container Registry
- Azure Container Registry (ACR)

## Version Control
- GitHub (with optional SSH deploy keys for private repos)
- GitHub PAT required for Backstage

## Helm
- Package manager for K8s deployments
- Custom values in `gitops/environments/default/addons/`
- All addons deployed via Helm charts
