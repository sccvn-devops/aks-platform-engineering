# AKS Platform Engineering - Complete Codebase Index

## Complete Directory Tree with Descriptions

```
aks-platform-engineering/
├── README.md                         # Main project documentation
├── CONTRIBUTING.md                   # Contribution guidelines & CLA info
├── CODE_OF_CONDUCT.md               # Microsoft Open Source Code of Conduct
├── CHANGELOG.md                      # Version history
├── LICENSE.md                        # MIT license
├── SECURITY.md                       # Security policy
├── SUPPORT.md                        # Support information
├── catalog-info.yaml                 # Backstage service definition
│
├── backstage/                        # DEVELOPER PORTAL (Lerna monorepo)
│   ├── package.json                  # Root workspace config, shared dev deps
│   ├── lerna.json                    # Lerna configuration
│   ├── tsconfig.json                 # TypeScript root config
│   ├── playwright.config.ts          # E2E test configuration
│   ├── backstage.json                # Backstage version (1.32.2)
│   ├── app-config.yaml               # Production runtime config
│   ├── app-config-local.yaml         # Local dev overrides
│   ├── catalog-info.yaml             # Backstage service entity
│   ├── Dockerfile                    # Container image definition
│   │
│   ├── backstagechart/               # HELM CHART for K8s deployment
│   │   ├── Chart.yaml                # Helm metadata
│   │   ├── values.yaml               # Default Helm values
│   │   └── templates/                # K8s manifest templates
│   │       ├── _helpers.tpl          # Template helpers
│   │       ├── deployment.yaml       # Backstage deployment
│   │       ├── service.yaml          # Service definition
│   │       ├── ingress.yaml          # Ingress configuration
│   │       ├── hpa.yaml              # Horizontal Pod Autoscaler
│   │       ├── serviceaccount.yaml   # Service account & RBAC
│   │       ├── NOTES.txt             # Post-install notes
│   │       └── tests/
│   │           └── test-connection.yaml
│   │
│   ├── etc/                          # Static configuration
│   │   └── tls/                      # TLS certificates (self-signed)
│   │
│   ├── packages/                     # LERNA WORKSPACES
│   │   ├── README.md
│   │   │
│   │   ├── app/                      # FRONTEND: React + TypeScript
│   │   │   ├── package.json          # Frontend dependencies
│   │   │   ├── public/               # Static assets
│   │   │   │   ├── index.html        # Entry HTML
│   │   │   │   ├── manifest.json     # PWA manifest
│   │   │   │   └── robots.txt        # SEO robots
│   │   │   └── src/
│   │   │       ├── apis.ts           # API client definitions
│   │   │       ├── App.tsx           # Root component
│   │   │       ├── App.test.tsx      # Root component tests
│   │   │       ├── index.tsx         # React entry point
│   │   │       ├── setupTests.ts     # Jest config
│   │   │       ├── components/
│   │   │       │   ├── catalog/      # Catalog UI components
│   │   │       │   ├── Root/         # Root layout components
│   │   │       │   └── search/       # Search UI components
│   │   │       └── e2e-tests/
│   │   │           └── app.test.ts   # Playwright E2E tests
│   │   │
│   │   ├── backend/                  # BACKEND: Node.js + TypeScript
│   │   │   ├── package.json          # Backend dependencies
│   │   │   ├── README.md
│   │   │   └── src/
│   │   │       ├── index.ts          # Server entry point
│   │   │       └── plugins/          # Plugin initialization
│   │   │
│   │   ├── examples/                 # SAMPLE DATA & TEMPLATES
│   │   │   ├── entities.yaml         # Sample entity definitions
│   │   │   ├── org.yaml              # Organization structure
│   │   │   └── template/             # Software template example
│   │   │       ├── template.yaml     # Template definition
│   │   │       └── content/
│   │   │           ├── catalog-info.yaml
│   │   │           ├── package.json
│   │   │           └── gitops/       # Sample GitOps manifests
│   │   │
│   │   └── template-cluster/         # CLUSTER TEMPLATE
│   │       └── template.yaml         # Template for new clusters
│   │
│   └── plugins/                      # CUSTOM BACKSTAGE PLUGINS
│       └── README.md
│
├── terraform/                        # INFRASTRUCTURE AS CODE
│   ├── main.tf                       # Core infrastructure definition
│   ├── provider.tf                   # Azure provider configuration
│   ├── variables.tf                  # Input variables
│   ├── outputs.tf                    # Output values (kubeconfig, etc.)
│   ├── tfvars                        # Example terraform.tfvars
│   ├── openssl.cnf                   # SSL cert generation config
│   ├── cluster_info.txt              # Generated cluster info (post-deploy)
│   ├── kubeconfig                    # Generated kubeconfig (post-deploy)
│   └── bootstrap/
│       └── addons.yaml               # Addon installation config
│
├── gitops/                           # GITOPS DEFINITIONS (ArgoCD)
│   │
│   ├── apps/                         # APPLICATION DEPLOYMENTS
│   │   └── myapp/
│   │       └── AKSStoreDemoArgoApp.yaml
│   │
│   ├── bootstrap/                    # CONTROL PLANE SETUP
│   │   ├── control-plane/
│   │   │   └── addons/
│   │   │       ├── azure/            # Azure-specific (CAPZ/Crossplane)
│   │   │       │   ├── addons-azure-cluster-api-operator.yaml
│   │   │       │   └── addons-azure-oss-crossplane-upbound.yaml
│   │   │       └── oss/              # Open source addons
│   │   │           └── [ArgoCD apps for ArgoCD, Argo Rollouts, Argo Events, 
│   │   │               Argo Workflows, Kargo, etc.]
│   │   │
│   │   └── workloads/                # WORKLOAD CLUSTER SETUP
│   │       └── infra/
│   │           ├── argo-rollouts.yaml
│   │           ├── argocd-infra-project.yaml
│   │           └── [...other infra setup...]
│   │
│   ├── clusters/                     # CLUSTER DEFINITIONS
│   │   ├── clusters-argo-applicationset.yaml
│   │   ├── capz/                     # Cluster API Provider for Azure
│   │   │   ├── aks-appset.yaml       # ApplicationSet for AKS clusters
│   │   │   ├── argo-helmchartproxy.yaml
│   │   │   └── [cluster definitions...]
│   │   │
│   │   └── crossplane/               # Crossplane infrastructure
│   │       ├── kustomization.yaml
│   │       ├── base/
│   │       │   ├── cluster/
│   │       │   └── [base definitions...]
│   │       └── clusters/
│   │           └── my-app-cluster/
│   │
│   ├── environments/                 # ENVIRONMENT CONFIGS
│   │   └── default/
│   │       └── addons/               # Addon values (Helm overrides)
│   │           ├── argo-cd/          # ArgoCD custom values
│   │           ├── argo-workflows/
│   │           ├── cluster-api-operator/
│   │           ├── cluster-api-provider-azure/
│   │           ├── crossplane-azure-upbound/
│   │           └── kargo/
│   │
│   └── hooks/                        # LIFECYCLE HOOKS
│       ├── identity/                 # Identity/auth setup
│       │   ├── identity.yaml
│       │   └── kustomization.yaml
│       └── sleep/
│           └── sleep.yaml
│
├── docs/                             # DOCUMENTATION
│   ├── backstage.md                  # Backstage setup guide
│   ├── capz-or-crossplane.md         # Infrastructure provider comparison
│   └── Onboard-New-Dev-Team.md       # Team onboarding guide
│
└── images/                           # DIAGRAMS & ASSETS
    └── AKS-platform-engineering-architecture.png
```

## Key Dependencies & Imports

### Root `backstage/package.json` Key Dependencies
- `@backstage/cli: ^0.28.0` - Build & dev tooling
- `@backstage/e2e-test-utils: ^0.1.1` - E2E test helpers
- `@playwright/test: ^1.32.3` - Browser testing
- `concurrently: ^8.0.0` - Run multiple commands
- `lerna: ^7.3.0` - Monorepo management
- `typescript: ~5.2.0` - Type checking
- `prettier: ^2.3.2` - Code formatting

### Frontend `packages/app/package.json` (Typical)
- React components from `@backstage/core-components`
- `@backstage/catalog-client` - Catalog API client
- `@backstage/plugin-*` - Various plugins

### Backend `packages/backend/package.json` (Typical)
- `@backstage/backend-common` - Common utilities
- `@backstage/backend-plugin-api` - Plugin interface
- `express` - Web framework

## Configuration Files Map

| Config File | Purpose | Format |
|------------|---------|--------|
| `backstage/app-config.yaml` | Backstage runtime (prod) | YAML |
| `backstage/app-config-local.yaml` | Backstage runtime (dev) | YAML |
| `backstage/backstage.json` | Version info | JSON |
| `backstage/lerna.json` | Monorepo config | JSON |
| `backstage/tsconfig.json` | TypeScript options | JSON |
| `backstage/playwright.config.ts` | E2E test options | TypeScript |
| `terraform/variables.tf` | Terraform inputs | HCL |
| `terraform/openssl.cnf` | SSL cert generation | OpenSSL config |
| `gitops/environments/*/addons/*/values.yaml` | Helm overrides | YAML |

## Important Code Entry Points

### Backstage Frontend
- **Entry**: `backstage/packages/app/src/index.tsx`
- **Root**: `backstage/packages/app/src/App.tsx`
- **Routes**: Defined in App.tsx

### Backstage Backend
- **Entry**: `backstage/packages/backend/src/index.ts`
- **Plugins**: Loaded from `src/plugins/`

### Terraform Provisioning
- **Entry**: `terraform/main.tf`
- **Variables**: `terraform/variables.tf`
- **Locals**: Computed values in main.tf (addons config)

### GitOps Control
- **Control Plane Addons**: `gitops/bootstrap/control-plane/addons/`
- **Cluster Templates**: `gitops/clusters/capz/` or `gitops/clusters/crossplane/`
- **Environment Overrides**: `gitops/environments/default/addons/`

## Build Artifacts (Post-Deploy)

Created by Terraform:
- `terraform/kubeconfig` - Cluster access credentials
- `terraform/cluster_info.txt` - Cluster information

Created by Kubernetes/ArgoCD:
- Helm releases in addon namespaces
- ArgoCD Applications in argocd namespace
- Backend images in Azure Container Registry

## Workspace Configuration

### Lerna Workspaces
- Monorepo root: `backstage/`
- Package locations: `packages/*` and `plugins/*`
- Package interdependencies resolved by Lerna
- Single `node_modules` with hoisting
- Shared build tools via root `package.json`

### Yarn Workspace Scripts
- Available scripts defined in `backstage/package.json`
- Run per-package: `yarn workspace <pkg> <script>`
- Run all: `yarn workspaces foreach -A run <script>`

## Key Decision Points

### Infrastructure Choice (Variable: `infrastructure_provider`)
- **CAPZ** (default): Cluster API Provider for Azure
- **Crossplane**: Alternative infrastructure management

### Features Toggle
- Addon flags: `enable_<feature>` pattern in variables
- Backend build: `build_backstage` variable
- Default enabled: ArgoCD, Argo Rollouts, Argo Events, Argo Workflows, Kargo

### Authentication
- Backstage: Azure Entra ID
- Cluster: Kubeconfig (kubectl)
- Git access: GitHub PAT (optional SSH keys)
