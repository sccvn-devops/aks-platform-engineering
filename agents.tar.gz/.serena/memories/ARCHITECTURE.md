# AKS Platform Engineering - Architecture

## High-Level Pattern
Uses **GitOps Bridge Pattern** - reconciles infrastructure git state with cluster state.

## Deployment Model

### Control Plane Cluster
- Deployed via Terraform + ArgoCD
- Hosts core infrastructure services & Day 2 operations tools
- Installed with addons from `gitops/bootstrap/control-plane/addons/`
- Includes identity hooks (`gitops/hooks/identity/`)

### Workload Clusters (Per Dev Team)
- Provisioned by Platform Engineering team
- Auto-installs infrastructure tools via ArgoCD
- Dev teams can customize with Policy enforcement
- Deployed via `gitops/clusters/` definitions

## Infrastructure Provider Options (Configurable)
**Variable: `infrastructure_provider`** (default: `capz`)

1. **CAPZ** (Cluster API Provider for Azure)
   - Default option
   - Includes Azure Service Operator (ASO) for CRDs
   - Customizable via `gitops/environments/default/addons/cluster-api-provider-azure/values.yaml`

2. **Crossplane**
   - Alternative infrastructure management
   - Includes Crossplane Upbound provider
   - Helm & Kubernetes providers enabled

## Core Addon Components

### Always Enabled
- ArgoCD (GitOps controller)
- Argo Rollouts (Progressive delivery)
- Argo Events (Event-driven workflows)
- Argo Workflows (Workflow automation)
- Kargo (Progressive delivery orchestration)

### Conditionally Enabled (Infrastructure Provider Dependent)
- Cluster API Operator (CAPZ)
- Cert Manager (CAPZ or manual)
- Azure Crossplane Upbound Provider (Crossplane)

### Optional Addons
- Cluster Proportional Autoscaler
- Gatekeeper (Policy enforcement)
- GPU Operator
- Ingress NGINX
- Kyverno (Policy management)
- Kube Prometheus Stack
- Metrics Server
- Prometheus Adapter
- Secrets Store CSI Driver
- VPA (Vertical Pod Autoscaler)

## Workflow
1. Platform team forks repo & customizes
2. Terraform provisions control plane cluster + ArgoCD
3. ArgoCD syncs gitops/bootstrap/ to cluster
4. Team onboards → workload clusters created
5. Dev teams deploy apps using GitOps (ArgoCD)

## TLS/Security
- Self-signed certificates for Backstage HTTPS
- Generated via openssl.cnf (awaiting automation)
- Kubernetes TLS secrets in `backstage/etc/tls/`
