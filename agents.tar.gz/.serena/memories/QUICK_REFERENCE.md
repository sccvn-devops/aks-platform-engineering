# AKS Platform Engineering - Quick Reference

## Project at a Glance
- **Type**: Azure platform engineering reference architecture
- **Stack**: AKS + ArgoCD + Backstage + Terraform
- **Monorepo**: Lerna + Yarn workspaces
- **Infrastructure**: CAPZ or Crossplane (configurable)
- **Deployment**: GitOps (Infrastructure as Code)

## Key Files to Know

| File | Purpose |
|------|---------|
| `terraform/main.tf` | Core Terraform configuration |
| `terraform/variables.tf` | Configurable inputs (infrastructure_provider, github_token, etc.) |
| `backstage/package.json` | Root monorepo package, workspace definitions |
| `backstage/app-config.yaml` | Backstage runtime configuration |
| `gitops/bootstrap/control-plane/addons/` | Addons deployed to control plane |
| `gitops/environments/default/addons/` | Addon custom values (Helm) |
| `docs/backstage.md` | Backstage setup guide |
| `docs/capz-or-crossplane.md` | Infrastructure provider comparison |

## Important Variables & Configuration

### Terraform (terraform/variables.tf)
```
resource_group_name     = "aks-gitops"           # Azure resource group
location                = "eastus2"              # Azure region
infrastructure_provider = "capz" | "crossplane"  # Infrastructure management
github_token            = ""                     # PAT for Backstage
build_backstage         = true/false             # Deploy Backstage
gitops_addons_org       = "https://github.com/..." # Git repo URL
```

### Backstage Config (backstage/app-config*.yaml)
- Backend port & CORS settings
- Plugin configurations
- Database connections
- Authentication providers (Azure Entra ID)

## Common Tasks

### Deploy Control Plane
```bash
cd terraform
terraform init -upgrade
terraform apply -var gitops_addons_org=https://github.com/<fork> --auto-approve
```

### Develop Backstage Locally
```bash
cd backstage
yarn install
yarn dev
```

### Access ArgoCD
```bash
kubectl port-forward svc/argocd-server 8080:443 -n argocd
# Password: kubectl get secret argocd-initial-admin-secret -n argocd --template="{{index .data.password | base64decode}}"
```

### Deploy New Workload Cluster
- Create cluster definition in `gitops/clusters/`
- Choose CAPZ or Crossplane template
- Commit & push
- ArgoCD auto-syncs

### Add Custom Addon
- Create values file in `gitops/environments/default/addons/<addon-name>/`
- Reference in ArgoCD ApplicationSet
- ArgoCD deploys to clusters

## Manual Steps (To Automate)

1. **Backstage TLS Certificate** - Currently manual using openssl.cnf
   - Generate: `openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout tls.key -out tls.crt -config openssl.cnf`
   - Update K8s secret: `kubectl create secret tls my-tls-secret --key=tls.key --cert=tls.crt -n backstage`
   - Restart: `kubectl rollout restart deployment backstage-backstagechart -n backstage`

2. **Entra ID Admin Consent** - Required for Backstage to sync users
   - Azure Portal: Entra → App registrations → Backstage → API Permissions → Grant admin consent
   - Or CLI: `az ad app permission admin-consent --id <ApplicationId>`

## Key Endpoints & Access

| Component | Access Method | Default Location |
|-----------|---|---|
| ArgoCD UI | Port forward | `https://localhost:8080` |
| Backstage | Service external IP | `https://<External-IP>` |
| Kubeconfig | File | `terraform/kubeconfig` |
| Cluster Info | File | `terraform/cluster_info.txt` |

## Documentation Structure

| Document | Content |
|----------|---------|
| `README.md` | Main overview & getting started |
| `docs/backstage.md` | Backstage-specific setup & features |
| `docs/capz-or-crossplane.md` | Comparison of infrastructure providers |
| `docs/Onboard-New-Dev-Team.md` | Team onboarding process |

## Important Constraints & Notes

- GitHub PAT required for Backstage feature (repository creation)
- SSH deploy keys needed only if using private Git repo
- Self-signed certs for HTTPS (not production-ready as-is)
- Entra ID admin consent required for user syncing
- Default Kubernetes version: Latest available in region
- Default VM size: Standard_D2s_v3

## File Size Warnings
- Large ArgoCD ApplicationSets in `gitops/clusters/`
- Monitor Terraform state file size with multiple clusters
- Backend package can grow with plugins

## Testing & Quality Assurance

```bash
yarn lint:all            # Check all linting
yarn test:all            # Run all unit tests
yarn test:e2e            # Run E2E tests (Playwright)
yarn prettier:check      # Format check
yarn fix                 # Auto-fix linting/formatting
```

## Useful Regex/Search Patterns

To find configuration across the repo:
- Addon definitions: `gitops/bootstrap/` and `gitops/environments/`
- Chart values: `values.yaml` files in addon directories
- Service definitions: `gitops/apps/`
- Cluster templates: `gitops/clusters/capz/` or `gitops/clusters/crossplane/`
