# AKS Platform Engineering - Setup & Build Commands

## Prerequisites
- **Azure CLI** v2.60.0+
- **Terraform** v1.8.3+
- **kubectl** v1.28.9+
- **Node.js** v18 or v20
- **Yarn** package manager

## Backstage Setup (Development)

### Initial Setup
```bash
cd backstage

# Install dependencies
yarn install

# Watch mode (frontend + backend)
yarn dev

# Frontend only
yarn start

# Backend only
yarn start-backend
```

### Build
```bash
# Build backend for Docker
yarn build:backend

# Build all packages
yarn build:all

# Create Docker image
yarn build-image
```

### Testing
```bash
# Unit tests (all packages)
yarn test
yarn test:all              # with coverage

# E2E tests (Playwright)
yarn test:e2e
```

### Code Quality
```bash
# TypeScript type checking
yarn tsc
yarn tsc:full             # without skipLibCheck

# Linting
yarn lint
yarn lint:all

# Format checking
yarn prettier:check

# Auto-fix issues
yarn fix

# Clean build artifacts
yarn clean
```

### Development
```bash
# Create new plugin/package
yarn new
```

## Terraform Deployment

### Initial Setup
```bash
cd terraform
terraform init -upgrade
```

### Control Plane (CAPZ - Default)
```bash
terraform apply \
  -var gitops_addons_org=https://github.com/<your-fork> \
  --auto-approve
```

### Control Plane (Crossplane)
```bash
terraform apply \
  -var gitops_addons_org=https://github.com/<your-fork> \
  -var infrastructure_provider=crossplane \
  --auto-approve
```

### With Backstage
```bash
terraform apply \
  -var build_backstage=true \
  -var gitops_addons_org=https://github.com/<your-fork> \
  -var github_token=<PAT> \
  --auto-approve
```

## Cluster Access

### Get Kubeconfig
```bash
export KUBECONFIG=<path>/aks-platform-engineering/terraform/kubeconfig
echo $KUBECONFIG
```

### ArgoCD Access
```bash
# Get admin password
kubectl get secrets argocd-initial-admin-secret \
  -n argocd \
  --template="{{index .data.password | base64decode}}"

# Port forward to UI
kubectl port-forward svc/argocd-server 8080:443 -n argocd
# Access: https://localhost:8080
```

### Backstage Access
```bash
# Get service IP
kubectl get svc backstage-backstagechart -n backstage

# Access via: https://<EXTERNAL_IP>
```

## Backstage TLS Certificate Setup

### Generate Self-Signed Cert
```bash
# Update openssl.cnf with your Backstage Public IP

# Generate cert
openssl req -x509 -nodes -days 365 \
  -newkey rsa:2048 \
  -keyout tls.key \
  -out tls.crt \
  -config openssl.cnf

# Update Kubernetes secret
kubectl delete secret my-tls-secret -n backstage
kubectl create secret tls my-tls-secret \
  --key=tls.key \
  --cert=tls.crt \
  -n backstage

# Restart Backstage
kubectl rollout restart deployment backstage-backstagechart -n backstage
```

## GitHub Configuration

### Private Repository Setup
If using private repo, create SSH deploy key:

```bash
# In repo settings: Settings → Deploy keys
# Create read-only SSH key
# Place private key at: terraform/private_ssh_deploy_key

# Update terraform variables:
# - gitops_addons_org: use git@github.com:... format
# - Uncomment line 218 of main.tf: sshPrivateKey = file(...)
```

### GitHub PAT Requirements for Backstage
**Permissions needed:**
- Full repo access (classic PATs)
- OR contents: Read+Write, Pull requests: Read+Write (fine-grained)

## Useful Commands

### Workspace Operations
```bash
# List workspaces
yarn workspaces list

# List workspace info
yarn workspaces info

# Run command in all packages
yarn workspaces foreach -A run <command>
```

### Terraform
```bash
# Dry-run
terraform plan

# Destroy
terraform destroy --auto-approve

# Get outputs
terraform output

# Get specific output
terraform output kubeconfig
```
