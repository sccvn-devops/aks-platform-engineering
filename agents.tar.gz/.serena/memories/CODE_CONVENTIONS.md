# AKS Platform Engineering - Code Conventions & Patterns

## Monorepo Structure (Lerna + Yarn Workspaces)

### Workspace Organization
```
packages/
  app/              - Backstage frontend (React/TS)
  backend/          - Backstage backend (Node.js)
  examples/         - Sample entities, templates
  template-cluster/ - Template for new clusters
plugins/
  <plugin-name>/    - Custom Backstage plugins
```

### Workspace Commands Pattern
Run in all workspaces:
```bash
yarn workspaces foreach -A run <script>
```

## Naming Conventions

### TypeScript Files
- React Components: PascalCase (e.g., `CatalogPage.tsx`)
- Utilities: camelCase (e.g., `apiClient.ts`)
- Tests: `*.test.ts` or `*.test.tsx`

### Directories
- Components: `components/` 
- Pages: Usually in `src/` for Backstage
- Tests: Adjacent to source (co-located)

## Backstage Patterns

### App Structure (`packages/app/`)
```
src/
  apis.ts              - API definitions
  App.tsx              - Root component
  App.test.tsx         - Root tests
  index.tsx            - Entry point
  setupTests.ts        - Test configuration
  components/
    catalog/           - Catalog-related components
    Root/              - Root layout
    search/            - Search components
```

### Backend Structure (`packages/backend/`)
```
src/
  index.ts             - Server entry point
  plugins/             - Plugin routing & initialization
  middleware/          - Express middleware
```

### Examples Directory
```
examples/
  entities.yaml        - Sample entity definitions
  org.yaml             - Organization structure
  template/
    template.yaml      - Software template definition
    content/           - Template source files
      catalog-info.yaml
      package.json
      gitops/          - GitOps manifests
```

## GitOps Patterns (ArgoCD)

### Application Structure
```
gitops/
  apps/
    <app-name>/
      <ArgoApp>.yaml   - ArgoCD Application definition
```

### Bootstrap Structure
```
gitops/bootstrap/
  control-plane/
    addons/
      azure/           - Azure-specific addons (CAPZ/Crossplane)
      oss/             - Open source addons (ArgoCD, Argo*, Kargo, etc.)
  workloads/
    infra/             - Infrastructure setup for workload clusters
```

### Addon Config Pattern
```
gitops/environments/default/addons/
  <addon-name>/
    Chart.yaml         - Chart metadata (optional if external chart)
    values.yaml        - Custom Helm values
    kustomization.yaml - Kustomize overlays (optional)
```

## Terraform Patterns

### Variable Naming
- Boolean flags: `enable_<feature>` (e.g., `enable_argocd`)
- Lists of objects: `<addon>_versions` with version strings
- URLs: `<service>_url` (e.g., `gitops_addons_url`)
- Paths: `<service>_path`, `<service>_basepath`

### Locals Usage
```hcl
locals {
  name                    = local.environment
  environment             = "control-plane"
  location                = var.location
  gitops_addons_url       = "${var.gitops_addons_org}/${var.gitops_addons_repo}"
  # ... computed values
}
```

### Conditional Feature Flag Pattern
```hcl
enable_feature = var.infrastructure_provider == "capz" ? true : false
```

## Configuration Patterns

### Backstage Config
- `app-config.yaml` - Production/deployment config
- `app-config-local.yaml` - Local development overrides
- Plugin configuration in `app-config*.yaml`

### Kubernetes Manifests
- ArgoCD Application definitions in YAML
- ApplicationSets for multi-cluster deployments
- Kustomization for overlays & patches

## Testing Patterns

### Playwright E2E Tests
- Location: `backstage/packages/app/e2e-tests/`
- Config: `playwright.config.ts`
- Pattern: `*.test.ts` files
- Run: `yarn test:e2e`

### Jest Unit Tests
- Location: Adjacent to source files (`*.test.ts`)
- Config: Inherited from Backstage CLI
- Run: `yarn test` or `yarn test:all`

## Development Workflow

### Local Development
```bash
yarn install
yarn dev              # Runs frontend + backend concurrently
```

### Feature Development (Typical)
1. Create feature branch
2. Add/modify code
3. Run linting: `yarn lint:all`
4. Run tests: `yarn test:all`
5. Check formatting: `yarn prettier:check`
6. Fix issues: `yarn fix`
7. Commit & create PR

### Plugin Development
```bash
yarn new              # Create new plugin
# Scaffold generated in plugins/<name>/
```

## Dependency Management

### Root `package.json`
- Defines workspace structure
- Controls shared dev dependencies
- Lerna configuration
- Script definitions for monorepo operations

### Per-Package `package.json`
- Package-specific dependencies
- Package name & version
- Per-package scripts

### Resolutions (Root)
- `@types/react: ^18` - Enforce React 18 types
- `@types/react-dom: ^18` - Enforce React DOM types

## Version Control

### Branching
- Default: `master` or `main`
- Feature branches
- PR-based workflow

### Commits
- Descriptive commit messages
- Can include issue references

### SSH Deploy Keys (Optional)
- For private repos
- Read-only access
- Stored in `terraform/private_ssh_deploy_key`

## Error Handling Notes

- Linter: ESLint with @backstage presets
- Prettier: Spotify configuration
- TypeScript: Strict checking recommended
- Ignore warnings about deprecated attributes in Terraform (per docs)
