# AKS Platform Engineering - Directory Structure

## Root Level Documentation
- `README.md` - Main project guide
- `CONTRIBUTING.md` - Contribution guidelines
- `CODE_OF_CONDUCT.md` - Microsoft OSS Code of Conduct
- `catalog-info.yaml` - Backstage entity definition
- `CHANGELOG.md`, `LICENSE.md`, `SECURITY.md`, `SUPPORT.md`

## Key Directories

### `/terraform/` - Infrastructure as Code
```
terraform/
├── main.tf               # Primary Terraform configuration
├── provider.tf           # Azure provider setup
├── variables.tf          # Input variables (resource_group, location, k8s_version, etc.)
├── outputs.tf            # Terraform outputs
├── tfvars                # Example tfvars file
├── openssl.cnf           # Self-signed cert config for Backstage
├── cluster_info.txt      # Generated cluster information
├── bootstrap/
│   └── addons.yaml       # Addon configuration
└── kubeconfig            # Generated kubeconfig (local access)
```

**Key Variables:**
- `resource_group_name` - Azure resource group
- `location` - Azure region (default: eastus2)
- `infrastructure_provider` - "capz" or "crossplane"
- `github_token` - PAT for Backstage
- `build_backstage` - Enable/disable Backstage deployment
- `gitops_addons_org` - GitHub org URL for addons repo

### `/backstage/` - Developer Portal
```
backstage/
├── package.json          # Root monorepo (Node 18|20, TypeScript)
├── lerna.json            # Lerna workspace config
├── tsconfig.json         # TypeScript configuration
├── playwright.config.ts  # E2E test config
├── app-config.yaml       # Backstage runtime config
├── app-config-local.yaml # Local development override
├── catalog-info.yaml     # Backstage service entity
├── Dockerfile            # Container image for Backstage
├── backstagechart/       # Helm chart for K8s deployment
│   ├── Chart.yaml
│   ├── values.yaml
│   └── templates/        # K8s manifests (deployment, service, ingress, HPA, etc.)
├── packages/
│   ├── app/              # Frontend (React/TypeScript)
│   │   ├── src/          # Source code (components, pages)
│   │   ├── public/       # Static assets
│   │   └── e2e-tests/    # Playwright E2E tests
│   ├── backend/          # Node.js backend
│   └── examples/         # Sample entities, templates, catalog
├── plugins/              # Backstage plugin extensions
└── etc/tls/              # TLS certificates
```

### `/gitops/` - GitOps Definitions (ArgoCD)
```
gitops/
├── apps/                 # Application deployments
│   └── myapp/
│       └── AKSStoreDemoArgoApp.yaml
├── bootstrap/            # Control plane bootstrapping
│   ├── control-plane/
│   │   └── addons/
│   │       ├── azure/
│   │       │   ├── addons-azure-cluster-api-operator.yaml
│   │       │   └── addons-azure-oss-crossplane-upbound.yaml
│   │       └── oss/      # Open source addons
│   └── workloads/        # Workload cluster setup
│       └── infra/
├── clusters/             # Cluster definitions
│   ├── clusters-argo-applicationset.yaml
│   ├── capz/             # CAPZ cluster manifests
│   └── crossplane/       # Crossplane cluster definitions
├── environments/         # Environment-specific configs
│   └── default/
│       └── addons/       # Addon values & configs
│           ├── argo-cd/
│           ├── argo-workflows/
│           ├── cluster-api-operator/
│           ├── cluster-api-provider-azure/
│           ├── crossplane-azure-upbound/
│           └── kargo/
└── hooks/                # Lifecycle hooks
    ├── identity/         # Identity/authentication setup
    └── sleep/
```

### `/docs/` - Documentation
- `backstage.md` - Backstage setup & usage guide
- `capz-or-crossplane.md` - Infrastructure provider comparison
- `Onboard-New-Dev-Team.md` - Team onboarding process

### `/images/` - Architecture diagrams & images
- `AKS-platform-engineering-architecture.png`

## Workspace Type
**Monorepo** - Uses Lerna + Yarn workspaces
```
packages/
  - app (React frontend)
  - backend (Node.js API)
  - examples (sample data)
  - template-cluster (template)
plugins/
  - custom extensions
```
